﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace Hydra_Password_Tools
{
    class Encoder
    {
        #region Functions
        
        /// <summary>
        /// Returns Base64 encoded string
        /// </summary>
        /// <param name="str">The string to be encoded</param>
        public string Base64Encoder(string str)
        {
            string result = null;
            try
            {
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(str);
                result = System.Convert.ToBase64String(plainTextBytes);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return result;
        }

        #endregion
    }
}
