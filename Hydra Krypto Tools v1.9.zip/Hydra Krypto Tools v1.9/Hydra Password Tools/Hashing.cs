﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace Hydra_Password_Tools
{
    class Hashing
    {
        #region Functions

        /// <summary>
        /// Calculates MD5 hash string
        /// </summary>
        /// <param name="input">The desired string</param>
        /// <returns>Returns MD5 hash string</returns>
        public string HashMD5(string input)
        {
            StringBuilder hash = new StringBuilder();
            MD5CryptoServiceProvider md5provider = new MD5CryptoServiceProvider();
            byte[] bytes = md5provider.ComputeHash(new UTF8Encoding().GetBytes(input));
            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }


        /// <summary>
        /// Calculates SHA-1 hash string
        /// </summary>
        /// <param name="input">The desired string</param>
        /// <returns>Returns SHA-1 hash string</returns>
        public string HashSHA1(string input)
        {
            StringBuilder hash = new StringBuilder();
            SHA1CryptoServiceProvider sha1provider = new SHA1CryptoServiceProvider();
            byte[] bytes = sha1provider.ComputeHash(new UTF8Encoding().GetBytes(input));
            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }


        /// <summary>
        /// Calculates SHA-256 hash string
        /// </summary>
        /// <param name="input">The desired string</param>
        /// <returns>Returns SHA-256 hash string</returns>
        public string HashSHA256(string input)
        {
            StringBuilder hash = new StringBuilder();
            SHA256CryptoServiceProvider sha256provider = new SHA256CryptoServiceProvider();
            byte[] bytes = sha256provider.ComputeHash(new UTF8Encoding().GetBytes(input));
            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }


        /// <summary>
        /// Calculates SHA-384 hash string
        /// </summary>
        /// <param name="input">The desired string</param>
        /// <returns>Returns SHA-384 hash string</returns>
        public string HashSHA384(string input)
        {
            StringBuilder hash = new StringBuilder();
            SHA384CryptoServiceProvider sha384provider = new SHA384CryptoServiceProvider();
            byte[] bytes = sha384provider.ComputeHash(new UTF8Encoding().GetBytes(input));
            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }


        /// <summary>
        /// Calculates SHA-512 hash string
        /// </summary>
        /// <param name="input">The desired string</param>
        /// <returns>Returns SHA-512 hash string</returns>
        public string HashSHA512(string input)
        {
            StringBuilder hash = new StringBuilder();
            SHA512CryptoServiceProvider sha512provider = new SHA512CryptoServiceProvider();
            byte[] bytes = sha512provider.ComputeHash(new UTF8Encoding().GetBytes(input));
            for (int i = 0; i < bytes.Length; i++)
            {
                hash.Append(bytes[i].ToString("x2"));
            }
            return hash.ToString();
        }

        #endregion
    }
}
