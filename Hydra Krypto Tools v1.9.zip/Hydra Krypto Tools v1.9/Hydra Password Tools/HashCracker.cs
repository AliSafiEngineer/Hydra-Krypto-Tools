﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;
namespace Hydra_Password_Tools
{
    class HashCracker : Hashing
    {
        #region Resources

        private string str, hash;
        private string orginal_input;
        public static bool stop = false;
        double currentline = 1, percentage;
        static Main MainForm = Application.OpenForms.OfType<Main>().FirstOrDefault();
        public string input { set; get; }
        public string hashtype { set; get; }
        public string Result { get; set; }
        public string openfile { get; set; }
        public string GetHash
        {
            get { return hash; }
            set { str = value; }
        }

        #endregion

        #region Constructors

        // Parametric constructor
        public HashCracker(string type)
        {
            if (type.Equals("md5"))
                hashtype = "md5";
            else if (type.Equals("sha1"))
                hashtype = "sha1";
            else if (type.Equals("sha256"))
                hashtype = "sha256";
            else if (type.Equals("sha384"))
                hashtype = "sha384";
            else if (type.Equals("sha512"))
                hashtype = "sha512";  
        }

        // Default constructor
        public HashCracker()
        {
            hashtype = "md5";
        }

        #endregion

        #region Functions

        /// <summary>
        /// Changes percentage
        /// </summary>
        /// <param name="percentage">The percentage number in string form</param>
        public static void ChangePercentage(string percentage)
        {
            MainForm.Invoke(new Action(() =>
            {
                percentage += " %";
                MainForm.decrypt_lbl_progress.Text = percentage;
            }));
            
        }


        /// <summary>
        /// Cracks the given hash with passphrase list
        /// </summary>
        public void crack()
        {
            try
            {
                StreamReader tmp = new StreamReader(openfile);
                tmp.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading file !\nError: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Result = "Error reading file !";
            }
            

            StreamReader read = new StreamReader(openfile);            
            double len = Convert.ToDouble(MainForm.decrypt_lbl_counted.Text);
            switch (this.hashtype)
            {
                case "md5":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }
                                
                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;

                            hash = HashMD5(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }
                case "sha1":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA1(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }

                case "sha256":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA256(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }

                case "sha384":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA384(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }

                case "sha512":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }
                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA512(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }
            }
        }

        #endregion

        // Hash functions
        /* Inherited */

        /*public void md5()
        {
            HashAlgorithm algorithm = MD5.Create();
            byte[] s = algorithm.ComputeHash(Encoding.UTF8.GetBytes(str));
            hash = BitConverter.ToString(s).Replace("-", "");
        }*/

        // For compare with this hash function: this.input.ToLower() == this.GetHash.Replace("-", "").ToLower()

    }
}
