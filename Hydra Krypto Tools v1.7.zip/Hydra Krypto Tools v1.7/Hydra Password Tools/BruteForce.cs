﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;

namespace Hydra_Password_Tools
{
    class BruteForce : HashCracker
    {
        private char[] charlist = {
                                    '0','1','2','3','4','5','6','7','8','9',
                                    'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','r','u','v','w','x','y','z',
                                    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','R','U','V','W','X','Y','Z',
                                    '!','@','#','$','%','&','*','^','(',')','_','-','+','=','`',
                                    ' ',',','.','\'','/','?','\\',';',':','"','<','>','[',']','{','}'
                                  };
        
        private int index = 0;
        List<string> stringlist = new List<string>();
        public string input { get; set; }
        public string hashtype { get; set; }
        public string GetHash
        {
            get { return hash; }
            set { str = value; }
        }
        public string Result { get; set; }
        private string orginal_input { set; get; }

        private string str, hash;

        // Parametric constructors
        public BruteForce(string type)
        {
            if (type.Equals("md5"))
                hashtype = "md5";
            else if (type.Equals("sha1"))
                hashtype = "sha1";
            else if (type.Equals("sha256"))
                hashtype = "sha256";
            else if (type.Equals("sha384"))
                hashtype = "sha384";
            else if (type.Equals("sha512"))
                hashtype = "sha512";

            FillList();
        }

        // Default constructor
        public BruteForce()
        {
            hashtype = "md5";
            FillList();
        }

        private void FillList()
        {
            for (int i = 0; i < charlist.Length; i++)
            {
                stringlist.Add(charlist[i].ToString()); // Filling the stringlist
            }
        }

        // bruteforce function
        private string bruteforce(int position, List<string> string_list)
        {
            List<int> mod_list = new List<int>();
            string output = "";

            while (position >= 0)
            {
                mod_list.Add(position % string_list.Count);
                position -= position % string_list.Count;
                position /= string_list.Count;
                position -= 1;
            }
            for (int i = (mod_list.Count - 1); i >= 0; i += -1)
                output += string_list[mod_list[i]];

            return output;
        }
        

        public void crack()
        {
            switch (this.hashtype)
            {
                case "md5":
                    {
                        while (true)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = bruteforce(index, stringlist);
                            this.GetHash = orginal_input;
                            hash = HashMD5(str);
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            index++;
                        }
                        break;
                    }
                case "sha1":
                    {
                        while (true)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = bruteforce(index, stringlist);
                            this.GetHash = orginal_input;
                            hash = HashSHA1(str);
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            index++;
                        }
                        break;
                    }

                case "sha256":
                    {
                        while (true)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = bruteforce(index, stringlist);
                            this.GetHash = orginal_input;
                            hash = HashSHA256(str);
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            index++;
                        }
                        break;
                    }

                case "sha384":
                    {
                        while (true)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = bruteforce(index, stringlist);
                            this.GetHash = orginal_input;
                            hash = HashSHA384(str);
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            index++;
                        }
                        break;
                    }

                case "sha512":
                    {
                        while (true)
                        {
                            if (stop)
                            {
                                Result = "Operation cancelled !";
                                break;
                            }
                            orginal_input = bruteforce(index, stringlist);
                            this.GetHash = orginal_input;
                            hash = HashSHA512(str);
                            if (this.input == this.GetHash)
                            {
                                Result = orginal_input;
                                break;
                            }
                            else
                            {
                                Result = "Passphrase not found !";
                            }
                            index++;
                        }
                        break;
                    }
            }
        }

        
        // Hash functions
        /* Inherited */
    }
}
