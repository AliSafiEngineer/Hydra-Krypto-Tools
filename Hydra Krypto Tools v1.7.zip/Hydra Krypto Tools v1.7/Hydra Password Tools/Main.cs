﻿using MaterialSkin;
using MaterialSkin.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hydra_Password_Tools
{
    public partial class Main : MaterialForm
    {
        int final_status = 0;
        bool dictionary_method = false, bruteforce_method = false, save_status = false;
        string user_input, tmp_enc = "", tmp_dec = "", passwd, finalpasswd, passphrase_list = "", filename = "", path = "";
        double total = 0, percentage = 0;
        ulong linenumber = 1;
        // user_input : get user input (Hash)         
        // passphrase_list : Passphrase file (File)
        // save_status : Is sile ready to save with Ctrl+S

        private List<string> list = new List<string>();
        private List<string> raw_list = new List<string>();
        private List<string> hashed_list = new List<string>();
        Hashing Hash = new Hashing();
        Encoder Encoder = new Encoder();
        Stopwatch watch_decryption = new Stopwatch();
        Stopwatch watch_lstgen = new Stopwatch();
        

        private readonly MaterialSkinManager skinManager;
        public Main()
        {
            InitializeComponent();
            skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue400, TextShade.WHITE);
        }

        // Functions declarations
        private bool CancellationPending(DoWorkEventArgs e)
        {
            bool cancel = false;
            if (BGWorker1.CancellationPending)
            {
                e.Cancel = true;
                cancel = true;
            }
            return cancel;
        }
        private void lblCrackStatus()
        {
            decrypt_lbl_status.Invoke(new Action(() =>
            {
                decrypt_lbl_status.ForeColor = Color.Blue;
                decrypt_lbl_status.Text = "Cracking...";
            }
                ));
        }
        public string Reverse(string str)
        {
            string reverse = null;
            int length = str.Length - 1;
            while (length >= 0)
            {
                reverse += str[length];
                length--;
            }
            return reverse;
        }

        private bool CrackMethodsUnchecked()
        {
            bool result = false;
            if (!dictionary_radioBtn.Checked && !bruteforce_radioBtn.Checked && !numerical_radioBtn.Checked && !alphabetical_az_radioBtn.Checked &&
                !alphabetical_azCapital_radioBtn.Checked && !base64_algorithm.Checked)
            {
                result = true;
            }

            return result;
        }

        private bool encryptAlgorithmsUnchecked()
        {
            bool result = false;
            if (!md5_Encrypt.Checked && !md5Reverse_Encrypt.Checked && !sha1_Encrypt.Checked && !sha256_Encrypt.Checked && !sha384_Encrypt.Checked &&
                !sha512_Encrypt.Checked && !base64_Encrypt.Checked)
            {
                result = true;
            }
            return result;
        }

        private bool decryptAlgorithmsUnchecked()
        {
            bool result = false;
            if (!md5_algorithm.Checked && !md5Reverse_algorithm.Checked && !sha1_algorithm.Checked && !sha256_algorithm.Checked &&
                !sha384_algorithm.Checked && !sha512_algorithm.Checked && !base64_algorithm.Checked)
            {
                result = true;
            }
            return result;
        }

        private void DisableEncryptionTypes(bool disabling = true)
        {
            if (disabling)
            {
                md5_algorithm.Enabled = false;
                md5Reverse_algorithm.Enabled = false;
                sha1_algorithm.Enabled = false;
                sha256_algorithm.Enabled = false;
                sha384_algorithm.Enabled = false;
                sha512_algorithm.Enabled = false;
                base64_algorithm.Enabled = false;
            }
            else
            {
                md5_algorithm.Enabled = true;
                md5Reverse_algorithm.Enabled = true;
                sha1_algorithm.Enabled = true;
                sha256_algorithm.Enabled = true;
                sha384_algorithm.Enabled = true;
                sha512_algorithm.Enabled = true;
                base64_algorithm.Enabled = true;
            }
        }
        private void DisableCrackMethodOptions(bool check = false)
        {
            if (!check)
            {
                dictionary_radioBtn.Checked = false;
                bruteforce_radioBtn.Checked = false;
                numerical_radioBtn.Checked = false;
                alphabetical_az_radioBtn.Checked = false;
                alphabetical_azCapital_radioBtn.Checked = false;
            }
            dictionary_radioBtn.Enabled = false;
            bruteforce_radioBtn.Enabled = false;
            numerical_radioBtn.Enabled = false;
            alphabetical_az_radioBtn.Enabled = false;
            alphabetical_azCapital_radioBtn.Enabled = false;
        }

        private void EnableCrackMethodOptions()
        {
            dictionary_radioBtn.Enabled = true;
            bruteforce_radioBtn.Enabled = true;
            numerical_radioBtn.Enabled = true;
            alphabetical_az_radioBtn.Enabled = true;
            alphabetical_azCapital_radioBtn.Enabled = true;
        }
        private void copyToClipboard(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch
            {
                MessageBox.Show("Passphrase cloudn't copy to Clipboard because Value cannot be null!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void enableReadOnly(int textbox)
        {
            if (textbox == 1)
            {
                if (tmp_enc != string.Empty)
                    encrypt_txtBoxResult.Text = tmp_enc;
                else
                    encrypt_txtBoxResult.Text = string.Empty;
            }
            else if (textbox == 2)
            {
                if (tmp_dec != string.Empty)
                    decrypt_txtBox_outputBox.Text = tmp_dec;
                else
                    decrypt_txtBox_outputBox.Text = string.Empty;
            }

        }

        private void Stoptimer_decryption()
        {
            watch_decryption.Stop();
            timer1.Enabled = false;
        }
        
        private void Stoptimer_lstgen()
        {
            watch_lstgen.Stop();
            timer2.Enabled = false;
        }

        private void Starttimer_lstgen()
        {
            watch_lstgen.Reset();
            watch_lstgen.Start();
            timer2.Start();
        }
        private bool hashValidation(string hash_type, string hash)
        {
            bool is_valid = true;
            if (hash_type == "MD5" && hash.Length != 32 || hash_type == "MD5 Reverse" && hash.Length != 32)
                hashValidityWarning(ref is_valid);
            else if (hash_type == "SHA-1" && hash.Length != 40)
                hashValidityWarning(ref is_valid);
            else if (hash_type == "SHA-256" && hash.Length != 64)
                hashValidityWarning(ref is_valid);
            else if (hash_type == "SHA-384" && hash.Length != 96)
                hashValidityWarning(ref is_valid);
            else if (hash_type == "SHA-512" && hash.Length != 128)
                hashValidityWarning(ref is_valid);

            return is_valid;
        }       

        private void hashValidityWarning(ref bool is_valid)
        {
            MessageBox.Show("Invalid Hash ! Please enter valid Hash", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            is_valid = false;
        }

        public void ChangePercentage(string percentage)
        {
            
            lstgen_lbl_progress.Invoke(new Action(() =>
            {
                percentage += " %";
                lstgen_lbl_progress.Text = percentage;
            }));

        }
        private void StatusLabelColorChange()
        {
            switch (decrypt_lbl_status.Text)
            {
                case "Invalid input !":
                    decrypt_lbl_status.ForeColor = Color.Red;
                    break;
                case "No passphrase list loaded !":
                    decrypt_lbl_status.ForeColor = Color.Red;
                    break;
                case "Passphrase list loaded !":
                    decrypt_lbl_status.ForeColor = Color.Red;
                    break;
                case "Passphrase Decoded successfully !":
                    decrypt_lbl_status.ForeColor = Color.Green;
                    break;
                case "Cracking...":
                    decrypt_lbl_status.ForeColor = Color.Blue;
                    break;
                case "Hash cracked successfully !":
                    decrypt_lbl_status.ForeColor = Color.Green;
                    break;
                case "Passphrase not found !":
                    decrypt_lbl_status.ForeColor = Color.Red;
                    break;
            }

            switch (lstgen_lbl_status.Text)
            {
                case "Generating...":
                    lstgen_lbl_status.ForeColor = Color.Blue;
                    break;
                case "List generated !":
                    lstgen_lbl_status.ForeColor = Color.Green;
                    break;
                case "Passphrase list loaded":
                    lstgen_lbl_status.ForeColor = Color.Green;
                    break;
            }
        }
        public int colorSchemeIndex { get; set; }

        private void materialFlatButton1_Click(object sender, EventArgs e)
        {
            if (colorSchemeIndex > 4) colorSchemeIndex = 0;

            // These are color schemes
            switch (colorSchemeIndex)
            {
                case 0:
                    skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
                    skinManager.ColorScheme = new ColorScheme(Primary.Green600, Primary.Green700, Primary.Green200, Accent.Red400, TextShade.WHITE);
                    groupBox2.ForeColor = Color.Black;
                    groupBox6.ForeColor = Color.Black;
                    groupBox7.ForeColor = Color.Black;
                    groupBox8.ForeColor = Color.Black;
                    groupBox9.ForeColor = Color.Black;
                    pictureBoxWhite.Visible = false;
                    pictureBoxWhite2.Visible = false;
                    pictureBoxWhite3.Visible = false;
                    pictureBoxBlack.Visible = true;
                    pictureBoxBlack2.Visible = true;
                    pictureBoxBlack3.Visible = true;
                    StatusLabelColorChange();
                    break;

                case 1:
                    skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
                    skinManager.ColorScheme = new ColorScheme(Primary.Purple800, Primary.Purple900, Primary.Purple500, Accent.Red400, TextShade.WHITE);
                    groupBox2.ForeColor = Color.Black;
                    groupBox6.ForeColor = Color.Black;
                    groupBox7.ForeColor = Color.Black;
                    groupBox8.ForeColor = Color.Black;
                    groupBox9.ForeColor = Color.Black;
                    pictureBoxWhite.Visible = false;
                    pictureBoxWhite2.Visible = false;
                    pictureBoxWhite3.Visible = false;
                    pictureBoxBlack.Visible = true;
                    pictureBoxBlack2.Visible = true;
                    pictureBoxBlack3.Visible = true;
                    StatusLabelColorChange();
                    break;

                case 2:
                    skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
                    skinManager.ColorScheme = new ColorScheme(Primary.Indigo500, Primary.Indigo700, Primary.Indigo100, Accent.Pink200, TextShade.WHITE);
                    groupBox2.ForeColor = Color.Black;
                    groupBox6.ForeColor = Color.Black;
                    groupBox7.ForeColor = Color.Black;
                    groupBox8.ForeColor = Color.Black;
                    groupBox9.ForeColor = Color.Black;
                    pictureBoxWhite.Visible = false;
                    pictureBoxWhite2.Visible = false;
                    pictureBoxWhite3.Visible = false;
                    pictureBoxBlack.Visible = true;
                    pictureBoxBlack2.Visible = true;
                    pictureBoxBlack3.Visible = true;
                    StatusLabelColorChange();
                    break;

                case 3:
                    skinManager.Theme = MaterialSkinManager.Themes.DARK;
                    skinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue400, TextShade.WHITE);
                    groupBox2.ForeColor = Color.White;
                    groupBox6.ForeColor = Color.White;
                    groupBox7.ForeColor = Color.White;
                    groupBox8.ForeColor = Color.White;
                    groupBox9.ForeColor = Color.White;
                    pictureBoxWhite.Visible = true;
                    pictureBoxWhite2.Visible = true;
                    pictureBoxWhite3.Visible = true;
                    pictureBoxBlack.Visible = false;
                    pictureBoxBlack2.Visible = false;
                    pictureBoxBlack3.Visible = false;
                    StatusLabelColorChange();
                    break;

                case 4:
                    skinManager.Theme = MaterialSkinManager.Themes.LIGHT;
                    skinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue400, TextShade.WHITE);
                    groupBox2.ForeColor = Color.Black;
                    groupBox6.ForeColor = Color.Black;
                    groupBox7.ForeColor = Color.Black;
                    groupBox8.ForeColor = Color.Black;
                    groupBox9.ForeColor = Color.Black;
                    pictureBoxWhite.Visible = false;
                    pictureBoxWhite2.Visible = false;
                    pictureBoxWhite3.Visible = false;
                    pictureBoxBlack.Visible = true;
                    pictureBoxBlack2.Visible = true;
                    pictureBoxBlack3.Visible = true;
                    StatusLabelColorChange();
                    break;
            }
            colorSchemeIndex++;
        }
        private void materialRaisedButton3_Click(object sender, EventArgs e)
        {
            if (BGWorker1.IsBusy)
            {
                MessageBox.Show("Operation is in pending...\nPlease first cancel operaiton !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (base64_algorithm.Checked)
            {
                MessageBox.Show("This type of encoding does not need passphrase list !", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (!dictionary_radioBtn.Checked)
            {
                MessageBox.Show("First you should select \"Dictionary attack\" crack method !", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Multiselect = false;
            openfile.Filter = "Text File|*.txt|All File|*.*";
            openfile.Title = "Browse file";
            if (openfile.ShowDialog() == DialogResult.OK)
            {
                decrypt_lbl_path.Text = openfile.FileName;
                passphrase_list = openfile.FileName;
                decrypt_lbl_status.ForeColor = Color.Green;
                decrypt_lbl_status.Text = "Passphrase list loaded";
                list.Clear();
                try
                {
                    list.AddRange(File.ReadAllLines(openfile.FileName));
                    decrypt_lbl_counted.Text = list.Count.ToString();
                }
                catch
                {
                    decrypt_lbl_status.ForeColor = Color.Red;
                    decrypt_lbl_status.Text = "Error occured while reading file !";
                    return;
                }
            }

            else if (passphrase_list == string.Empty)
            {
                decrypt_lbl_path.Text = "None !";
                decrypt_lbl_counted.Text = "0";
                decrypt_lbl_status.ForeColor = Color.Red;
                decrypt_lbl_status.Text = "No passphrase list loaded !";
                decrypt_lbl_progress.Text = "0 %";
            }
        }
        
        private void materialRaisedButton4_Click(object sender, EventArgs e)
        {
            if (BGWorker1.IsBusy)
            {
                MessageBox.Show("Operation is in pending...\nPlease first cancel operaiton !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string type = "";
            decrypt_lbl_time.Text = "00:00:00";
            HashCracker.stop = false;
            BruteForce.stop = false; 

            if (decrypt_txtBox_inputHash.Text == string.Empty) 
            {
                MessageBox.Show("The input field cannot be null !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (md5_algorithm.Checked)
                type = "MD5";
            else if (md5Reverse_algorithm.Checked)
                type = "MD5 Reverse";
            else if (sha1_algorithm.Checked)
                type = "SHA-1";
            else if (sha256_algorithm.Checked)
                type = "SHA-256";
            else if (sha384_algorithm.Checked)
                type = "SHA-384";
            else if (sha512_algorithm.Checked)
                type = "SHA-512";

            if (!hashValidation(type, decrypt_txtBox_inputHash.Text))
                return;

            if (CrackMethodsUnchecked())
            {
                MessageBox.Show("Please choose crack method", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (dictionary_radioBtn.Checked && passphrase_list == string.Empty)
            {
                MessageBox.Show("Please first select your passphrase list", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (decryptAlgorithmsUnchecked())
            {
                MessageBox.Show("Please choose encryption type", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (dictionary_radioBtn.Checked && passphrase_list != string.Empty && decrypt_lbl_counted.Text == "0")
            {
                MessageBox.Show("The list is empty", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            } 

            decrypt_txtBox_outputBox.Text = tmp_dec = string.Empty;

            if (bruteforce_radioBtn.Checked || numerical_radioBtn.Checked || alphabetical_az_radioBtn.Checked || alphabetical_azCapital_radioBtn.Checked)
                decrypt_lbl_progress.Text = "None!";
            else
                decrypt_lbl_progress.Text = "0 %";

            DisableCrackMethodOptions(true); 
            DisableEncryptionTypes();
            user_input = decrypt_txtBox_inputHash.Text;
            if (!base64_algorithm.Checked)
            {
                watch_decryption.Reset();
                watch_decryption.Start();
                timer1.Enabled = true;
                BGWorker1.RunWorkerAsync();
            }
            
            // Base64 Decoder
            if (base64_algorithm.Checked)
            {
                try
                {
                    var base64EncodedBytes = Convert.FromBase64String(decrypt_txtBox_inputHash.Text);
                    decrypt_txtBox_outputBox.Text = tmp_dec = Encoding.UTF8.GetString(base64EncodedBytes);
                    decrypt_lbl_status.ForeColor = Color.Green;
                    decrypt_lbl_status.Text = "Base64 Decoded successfully !";
                    decrypt_lbl_progress.Text = "100 %";
                    copyToClipboard(decrypt_txtBox_outputBox.Text);
                }
                catch
                {
                    decrypt_lbl_status.ForeColor = Color.Red;
                    decrypt_lbl_status.Text = "Invalid input !";
                    decrypt_txtBox_outputBox.Text = string.Empty;
                }
            }

            
            if (base64_algorithm.Checked)
                DisableEncryptionTypes(false);
        }

        private void materialRaisedButton6_Click(object sender, EventArgs e)
        {
            if (BGWorker1.IsBusy)
            {
                MessageBox.Show("Operation is in pending...\nPlease first cancel operaiton !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            decrypt_txtBox_inputHash.Text = decrypt_txtBox_outputBox.Text = user_input = passphrase_list = finalpasswd = tmp_dec = string.Empty;
            decrypt_lbl_counted.Text = "0";
            decrypt_lbl_progress.Text = "0 %";
            decrypt_lbl_time.Text = "00:00:00";
            decrypt_lbl_path.Text = "None !";
            dictionary_radioBtn.Checked = bruteforce_radioBtn.Checked = numerical_radioBtn.Checked = 
            alphabetical_azCapital_radioBtn.Checked = alphabetical_az_radioBtn.Checked = md5_algorithm.Checked = 
            md5Reverse_algorithm.Checked = sha1_algorithm.Checked = sha256_algorithm.Checked =
            sha384_algorithm.Checked = sha512_algorithm.Checked = base64_algorithm.Checked = false;

            Color color;
            if (colorSchemeIndex == 4)
                color = Color.White;
            else
                color = Color.Black;

            decrypt_lbl_status.ForeColor = color;
            decrypt_lbl_status.Text = "None !";
        }
        private void materialRaisedButton5_Click(object sender, EventArgs e)
        {
            copyToClipboard(decrypt_txtBox_outputBox.Text);
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {
            if (encryptAlgorithmsUnchecked())
            {
                MessageBox.Show("Please choose encryption type", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // MD5
            if (md5_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Hash.HashMD5(encrypt_inputRaw.Text);

            // SHA-1
            else if (sha1_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Hash.HashSHA1(encrypt_inputRaw.Text);

            // MD5 Reverse
            else if (md5Reverse_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Reverse(Hash.HashMD5(encrypt_inputRaw.Text));

            // SHA-256
            else if (sha256_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Hash.HashSHA256(encrypt_inputRaw.Text);


            // SHA-384
            else if (sha384_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Hash.HashSHA384(encrypt_inputRaw.Text);

            // SHA-512
            else if (sha512_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Hash.HashSHA512(encrypt_inputRaw.Text);
            
            // Base64
            if (base64_Encrypt.Checked)
                encrypt_txtBoxResult.Text = tmp_enc = Encoder.Base64Encoder(encrypt_inputRaw.Text);

            copyToClipboard(encrypt_txtBoxResult.Text);
        }
        private void BGWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            // Crack with Dictionary attack
            if (dictionary_radioBtn.Checked)
            {
                dictionary_method = true;
                lblCrackStatus();

                HashCracker Cracker = new HashCracker();
                if (md5_algorithm.Checked)
                    Cracker.input = user_input;
       
                else if (md5Reverse_algorithm.Checked)
                    Cracker.input = Reverse(user_input);
                                        
                else if (sha1_algorithm.Checked)
                {
                    Cracker.hashtype = "sha1";
                    Cracker.input = user_input;
                }
                    
                else if (sha256_algorithm.Checked)
                {
                    Cracker.hashtype = "sha256";
                    Cracker.input = user_input;
                }
                    
                else if (sha384_algorithm.Checked)
                {
                    Cracker.hashtype = "sha384";
                    Cracker.input = user_input;
                }

                else if (sha512_algorithm.Checked)
                {
                    Cracker.hashtype = "sha512";
                    Cracker.input = user_input;
                }

                Cracker.openfile = passphrase_list;
                Cracker.crack();
                finalpasswd = Cracker.Result;

                decrypt_txtBox_outputBox.Invoke(new Action(() =>
                {
                    if (finalpasswd.Equals("Operation cancelled !"))
                        final_status = 2;

                    else if (finalpasswd.Equals("Passphrase not found !"))
                        final_status = 1;

                    else if (finalpasswd.Equals("Error reading file !"))
                        final_status = 3;

                    else
                        final_status = 0;
                }));
            }

            // Crack with Bruteforce
            else if (bruteforce_radioBtn.Checked)
            {
                bruteforce_method = true;
                lblCrackStatus();
                BruteForce Bruteforce = new BruteForce();

                if (md5_algorithm.Checked)
                    Bruteforce.input = user_input;

                else if (md5Reverse_algorithm.Checked)
                    Bruteforce.input = Reverse(user_input);

                else if (sha1_algorithm.Checked)
                {
                    Bruteforce.hashtype = "sha1";
                    Bruteforce.input = user_input;
                }

                else if (sha256_algorithm.Checked)
                {
                    Bruteforce.hashtype = "sha256";
                    Bruteforce.input = user_input;
                }

                else if (sha384_algorithm.Checked)
                {
                    Bruteforce.hashtype = "sha384";
                    Bruteforce.input = user_input;
                }

                else if (sha512_algorithm.Checked)
                {
                    Bruteforce.hashtype = "sha512";
                    Bruteforce.input = user_input;
                }

                Bruteforce.crack();
                finalpasswd = Bruteforce.Result;
                decrypt_txtBox_outputBox.Invoke(new Action(() =>
                {
                    if (finalpasswd == "Operation cancelled !")
                        final_status = 2;

                    else if (finalpasswd == "Passphrase not found !")
                        final_status = 1;

                    else
                        final_status = 0;
                }));
            }

            // Crack with numerical
            else if (numerical_radioBtn.Checked)
            {
                string hash = "";
                decimal i = 1;
                lblCrackStatus();

                while (true)
                {
                    if (CancellationPending(e))
                        return;

                    passwd = Convert.ToString(i);
                    if (md5_algorithm.Checked)
                        hash = Hash.HashMD5(passwd);

                    else if (md5Reverse_algorithm.Checked)
                        hash = Reverse(Hash.HashMD5(passwd));

                    else if (sha1_algorithm.Checked)
                        hash = Hash.HashSHA1(passwd);

                    else if (sha256_algorithm.Checked)
                        hash = Hash.HashSHA256(passwd);

                    else if (sha384_algorithm.Checked)
                        hash = Hash.HashSHA384(passwd);

                    else if (sha512_algorithm.Checked)
                        hash = Hash.HashSHA512(passwd);

                    if (hash == decrypt_txtBox_inputHash.Text)
                    {
                        final_status = 0;
                        finalpasswd = passwd;
                        break;
                    }
                    i++;
                }
            }

            // Crack with alphabetic a-z
            else if (alphabetical_az_radioBtn.Checked)
            {
                string hash = "";
                decimal i = 1;
                lblCrackStatus();

                while (true)
                {
                    if (CancellationPending(e))
                        return;
                    passwd = PasswordGenerator.passwdGenerator_az(i);

                    if (md5_algorithm.Checked)
                        hash = Hash.HashMD5(passwd);

                    else if (md5Reverse_algorithm.Checked)
                        hash = Reverse(Hash.HashMD5(passwd));

                    else if (sha1_algorithm.Checked)
                        hash = Hash.HashSHA1(passwd);

                    else if (sha256_algorithm.Checked)
                        hash = Hash.HashSHA256(passwd);

                    else if (sha384_algorithm.Checked)
                        hash = Hash.HashSHA384(passwd);

                    else if (sha512_algorithm.Checked)
                        hash = Hash.HashSHA512(passwd);

                    if (hash == decrypt_txtBox_inputHash.Text)
                    {
                        final_status = 0;
                        finalpasswd = passwd;
                        break;
                    }
                    i++;
                }
            }

            // Crack with alphabetic A-Z
            else if (alphabetical_azCapital_radioBtn.Checked)
            {
                string hash = "";
                decimal i = 1;
                lblCrackStatus();

                while (true)
                {
                    if (CancellationPending(e))
                        return;
                    passwd = PasswordGenerator.passwdGenerator_AZ(i);

                    if (md5_algorithm.Checked)
                        hash = Hash.HashMD5(passwd);

                    else if (md5Reverse_algorithm.Checked)
                        hash = Reverse(Hash.HashMD5(passwd));

                    else if (sha1_algorithm.Checked)
                        hash = Hash.HashSHA1(passwd);

                    else if (sha256_algorithm.Checked)
                        hash = Hash.HashSHA256(passwd);

                    else if (sha384_algorithm.Checked)
                        hash = Hash.HashSHA384(passwd);

                    else if (sha512_algorithm.Checked)
                        hash = Hash.HashSHA512(passwd);

                    if (hash == decrypt_txtBox_inputHash.Text)
                    {
                        final_status = 0;
                        finalpasswd = passwd;
                        break;
                    }
                    i++;
                }
             }
         }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            copyToClipboard(encrypt_txtBoxResult.Text);
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            pictureBoxWhite2.Hide();
            pictureBoxBlack2.Show();
        }

        private void BGWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            decrypt_lbl_progress.Text = e.ProgressPercentage.ToString("0.00") + " %";
        }

        private void BGWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                decrypt_lbl_status.ForeColor = Color.Red;
                decrypt_lbl_status.Text = "Operation cancelled";
            }
            else if (e.Error != null)
            {
                decrypt_lbl_status.Text = e.Error.ToString();
            }
            else
            {
                if (final_status == 0)
                {
                    decrypt_lbl_status.ForeColor = Color.Green;
                    decrypt_lbl_status.Text = "Hash cracked successfully !";
                    decrypt_txtBox_outputBox.Text = tmp_dec = finalpasswd;
                    copyToClipboard(decrypt_txtBox_outputBox.Text);
                }
                else if (final_status == 1)
                {
                    decrypt_lbl_status.ForeColor = Color.Red;
                    decrypt_lbl_status.Text = "Passphrase not found !";
                    decrypt_txtBox_outputBox.Text = tmp_dec = string.Empty;
                }
                else if (final_status == 3)
                {
                    decrypt_lbl_status.ForeColor = Color.Red;
                    decrypt_lbl_status.Text = "Error reading file !";
                    decrypt_lbl_progress.Text = "0 %";
                    decrypt_txtBox_outputBox.Text = tmp_dec = string.Empty;
                }
                else
                {
                    decrypt_lbl_status.ForeColor = Color.Red;
                    decrypt_lbl_status.Text = "Operation cancelled";
                }
            }

            dictionary_method = false;
            bruteforce_method = false;
            Stoptimer_decryption();
            DisableEncryptionTypes(false);
            EnableCrackMethodOptions();
            if (decrypt_txtBox_outputBox.Text != string.Empty)
                copyToClipboard(decrypt_txtBox_outputBox.Text);
        }
        private void materialRaisedButton3_Click_1(object sender, EventArgs e)
        {
            Stoptimer_decryption();
            if (dictionary_method || bruteforce_method)
            {
                HashCracker.stop = true;
                decrypt_lbl_status.ForeColor = Color.Red;
                decrypt_lbl_status.Text = "Operation cancelled";
            }
            if (BGWorker1.IsBusy)
                BGWorker1.CancelAsync();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://github.com/GuiltyAngel");
        }

        private void lstgen_btn_browse_Click_1(object sender, EventArgs e)
        {
            if (BGWorker2.IsBusy)
                MessageBox.Show("Operation is in pending...\nPlease wait until operation completed !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                OpenFileDialog openfile = new OpenFileDialog();
                openfile.Multiselect = false;
                openfile.Filter = "Text File|*.txt|All File|*.*";
                openfile.Title = "Browse file";
                if (openfile.ShowDialog() == DialogResult.OK)
                {
                    lstgen_lbl_path.Text = openfile.FileName;
                    filename = openfile.FileName; // Delete filename
                    lstgen_lbl_status.ForeColor = Color.Green;
                    lstgen_lbl_status.Text = "Passphrase list loaded";
                    list.Clear();
                    try
                    {
                        list.AddRange(File.ReadAllLines(openfile.FileName));
                        lstgen_lbl_counted.Text = list.Count.ToString();
                    }
                    catch
                    {
                        lstgen_lbl_status.ForeColor = Color.Red;
                        lstgen_lbl_status.Text = "Error occured while reading file !";
                        return;
                    }
                }

                else if (filename == string.Empty)
                {
                    lstgen_lbl_path.Text = "None !";
                    lstgen_lbl_counted.Text = "0";
                    lstgen_lbl_status.ForeColor = Color.Red;
                    lstgen_lbl_status.Text = "No passphrase list loaded !";
                    lstgen_lbl_progress.Text = "0 %";
                }
            }
        }

        private void lstgen_btn_reset_Click_1(object sender, EventArgs e)
        {
            if (BGWorker2.IsBusy)
            {
                MessageBox.Show("Operation is in pending...\nPlease wait until operation completed !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            filename = string.Empty;
            
            md5_hashlist.Checked = md5Reverse_hashlist.Checked = sha1_hashlist.Checked = sha256_hashlist.Checked =
            sha384_hashlist.Checked = sha512_hashlist.Checked = base64_hashlist.Checked = false;
            hashlist_autosave.Checked = false;
            lstgen_lbl_path.Text = "None !";
            lstgen_lbl_counted.Text = "0";

            Color color;
            if (colorSchemeIndex == 4)
                color = Color.White;
            else
                color = Color.Black;

            lstgen_lbl_status.ForeColor = color;
            lstgen_lbl_status.Text = "None !";
            lstgen_lbl_time.Text = "00:00:00";
            lstgen_lbl_progress.Text = "0 %";
        }

        private void lstgen_btn_gnrt_Click_1(object sender, EventArgs e)
        {
            if (filename == string.Empty)
            {
                MessageBox.Show("Please first select your passphrase list", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return;
            }
            else if (!md5_hashlist.Checked && !md5Reverse_hashlist.Checked && !sha1_hashlist.Checked && !sha256_hashlist.Checked &&
                     !sha384_hashlist.Checked && !sha512_hashlist.Checked && !base64_hashlist.Checked)
            {
                MessageBox.Show("Please choose encryption type", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            else if (lstgen_lbl_counted.Text == "0")
            {
                MessageBox.Show("The list is empty", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (BGWorker2.IsBusy)
            {
                MessageBox.Show("Operation is in pending...\nPlease wait until operation completed !", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Starttimer_lstgen();
            hashed_list.Clear();
            raw_list.Clear();
            
            lstgen_lbl_progress.Text = "0 %";
            lstgen_lbl_time.Text = "00:00:00";

            total = Convert.ToDouble(lstgen_lbl_counted.Text);

            BGWorker2.RunWorkerAsync();
        }

        // Set Accept and Cancel button
        private void materialTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (materialTabControl1.SelectedIndex)
            {
                case 0:
                    AcceptButton = encrypt_btn_hash;
                    break;
                case 1:
                    AcceptButton = decrypt_btn_crack;
                    CancelButton = decrypt_btn_reset;
                    break;
                case 2:
                    AcceptButton = identifier_btn_identify;
                    CancelButton = identifier_btn_reset;
                    break;
                case 3:
                    AcceptButton = lstgen_btn_gnrt;
                    CancelButton = lstgen_btn_reset;
                    break;
                default:
                    AcceptButton = encrypt_btn_hash;
                    break;
            }
        }

        private void BGWorker2_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lstgen_lbl_progress.Text = e.ProgressPercentage.ToString("0.00") + " %";
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            lstgen_lbl_time.Invoke(new Action(() =>
            {
                lstgen_lbl_time.Text = string.Format("{0:hh\\:mm\\:ss}", watch_lstgen.Elapsed);
            }));
        }

        private void BGWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            lstgen_lbl_status.Invoke(new Action(() =>
            {
                lstgen_lbl_status.ForeColor = Color.Blue;
                lstgen_lbl_status.Text = "Generating...";
            }));

            raw_list.AddRange(File.ReadAllLines(filename));

            if (md5_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Hash.HashMD5(item));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
                    
            }
            else if (md5Reverse_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Reverse(Hash.HashMD5(item)));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
                    
            }
            else if (sha1_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Hash.HashSHA1(item));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
            }
            else if (sha256_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Hash.HashSHA256(item));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
            }
            else if (sha384_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Hash.HashSHA384(item));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
            }
            else if (sha512_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Hash.HashSHA512(item));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
            }
            else if (base64_hashlist.Checked)
            {
                foreach (var item in raw_list)
                {
                    hashed_list.Add(Encoder.Base64Encoder(item));
                    percentage = Double.Parse(((linenumber / total) * 100).ToString("0.0"));
                    ChangePercentage(percentage.ToString());
                    linenumber++;
                }
            }

            linenumber = 0;
        }
        private void BGWorker2_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Stoptimer_lstgen();
            lstgen_lbl_progress.Invoke(new Action(() =>
            {
                lstgen_lbl_progress.Text = "100 %";
                lstgen_lbl_status.ForeColor = Color.Green;
                lstgen_lbl_status.Text = "List generated !";
            }));

            if (hashlist_autosave.Checked)
            {
                string datetime = DateTime.Now.ToString("hh\\-mm\\-ss_MM-dd-yy");
                path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                path += @"\Hash list_" + datetime + ".txt";
                File.WriteAllLines(path, hashed_list);
                MessageBox.Show("Hash list was saved in Desktop", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                SaveFileDialog savefile = new SaveFileDialog();
                savefile.Title = "Save file";
                savefile.Filter = "Text | *.txt | All files | *.*";
                if (savefile.ShowDialog() == DialogResult.OK)
                {
                    path = savefile.FileName;
                    File.WriteAllLines(path, hashed_list);
                }
            }
        }

        private void lstgen_btn_browse_Click(object sender, EventArgs e)
        {
            
            
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            decrypt_lbl_time.Invoke(new Action(() =>
            {
                decrypt_lbl_time.Text = string.Format("{0:hh\\:mm\\:ss}", watch_decryption.Elapsed);
            }));
            
        }

        private void outputBox_TextChanged(object sender, EventArgs e)
        {
            enableReadOnly(2);
        }

        private void txtBoxResult_TextChanged(object sender, EventArgs e)
        {
            enableReadOnly(1);
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            txtBox_hashidnty.Text = string.Empty;
            lbl_identify.Text = "N/A";
        }

        private void base64_algorithm_CheckedChanged(object sender, EventArgs e)
        {
            if (base64_algorithm.Checked)
                DisableCrackMethodOptions();

            else
                EnableCrackMethodOptions();
        }

        private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://t.me/AliDesu");
        }

        private void Identify_Btn_Click(object sender, EventArgs e)
        {
            HashIdentify identifier = new HashIdentify();
            lbl_identify.Text = identifier.GetHashType(txtBox_hashidnty.Text);
        }
    }
}
        