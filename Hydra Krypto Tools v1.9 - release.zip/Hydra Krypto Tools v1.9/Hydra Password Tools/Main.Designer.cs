﻿namespace Hydra_Password_Tools
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.materialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.base64_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.md5_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha384_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha512_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha256_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha1_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.pictureBoxBlack = new System.Windows.Forms.PictureBox();
            this.pictureBoxWhite = new System.Windows.Forms.PictureBox();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.encrypt_txtBoxResult = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.encrypt_btn_hash = new MaterialSkin.Controls.MaterialRaisedButton();
            this.encrypt_inputRaw = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.md5Reverse_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.decrypt_lbl_time = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel17 = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_btn_stop = new MaterialSkin.Controls.MaterialRaisedButton();
            this.decrypt_lbl_progress = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_lbl_status = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel10 = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_btn_crack = new MaterialSkin.Controls.MaterialRaisedButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bruteforce_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.alphabetical_azCapital_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.alphabetical_az_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.numerical_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.dictionary_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.pictureBoxWhite2 = new System.Windows.Forms.PictureBox();
            this.sha256_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha384_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.base64_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha512_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.md5Reverse_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha1_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.decrypt_lbl_counted = new MaterialSkin.Controls.MaterialLabel();
            this.lbl_count = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_btn_reset = new MaterialSkin.Controls.MaterialRaisedButton();
            this.decrypt_txtBox_outputBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel11 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel8 = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_btn_browse = new MaterialSkin.Controls.MaterialRaisedButton();
            this.lbl_list = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_lbl_path = new MaterialSkin.Controls.MaterialLabel();
            this.md5_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel7 = new MaterialSkin.Controls.MaterialLabel();
            this.decrypt_txtBox_inputHash = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBoxBlack2 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.identifier_btn_reset = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pictureBoxBlack3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxWhite3 = new System.Windows.Forms.PictureBox();
            this.lbl_identify = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel13 = new MaterialSkin.Controls.MaterialLabel();
            this.identifier_btn_identify = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txtBox_hashidnty = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.materialLabel19 = new MaterialSkin.Controls.MaterialLabel();
            this.passgen_lbl_total = new MaterialSkin.Controls.MaterialLabel();
            this.passgen_lbl_time = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel27 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel28 = new MaterialSkin.Controls.MaterialLabel();
            this.passgen_lbl_progress = new MaterialSkin.Controls.MaterialLabel();
            this.passgen_lbl_status = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel31 = new MaterialSkin.Controls.MaterialLabel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.passgen_btn_gnrt = new MaterialSkin.Controls.MaterialRaisedButton();
            this.passgen_btn_reset = new MaterialSkin.Controls.MaterialRaisedButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtBox_len_passlist = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel24 = new MaterialSkin.Controls.MaterialLabel();
            this.txtBox_chars_passlist = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.lbl_chars = new MaterialSkin.Controls.MaterialLabel();
            this.passlist_autosave = new MaterialSkin.Controls.MaterialCheckBox();
            this.custom_passphrase_passlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.numeric_passlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.alphabet_az_passlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel35 = new MaterialSkin.Controls.MaterialLabel();
            this.alphabet_az_capital_passlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.passphrase_passlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.materialLabel22 = new MaterialSkin.Controls.MaterialLabel();
            this.lstgen_lbl_path = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel25 = new MaterialSkin.Controls.MaterialLabel();
            this.lstgen_lbl_time = new MaterialSkin.Controls.MaterialLabel();
            this.lstgen_lbl_counted = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel32 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel33 = new MaterialSkin.Controls.MaterialLabel();
            this.lstgen_lbl_progress = new MaterialSkin.Controls.MaterialLabel();
            this.lstgen_lbl_status = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel36 = new MaterialSkin.Controls.MaterialLabel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lstgen_btn_gnrt = new MaterialSkin.Controls.MaterialRaisedButton();
            this.lstgen_btn_reset = new MaterialSkin.Controls.MaterialRaisedButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.hashlist_autosave = new MaterialSkin.Controls.MaterialCheckBox();
            this.base64_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel18 = new MaterialSkin.Controls.MaterialLabel();
            this.sha384_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.lstgen_btn_browse = new MaterialSkin.Controls.MaterialRaisedButton();
            this.sha1_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha512_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.md5_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel20 = new MaterialSkin.Controls.MaterialLabel();
            this.md5Reverse_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha256_hashlist = new MaterialSkin.Controls.MaterialRadioButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.materialLabel14 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel12 = new MaterialSkin.Controls.MaterialLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.materialLabel9 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel16 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel15 = new MaterialSkin.Controls.MaterialLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.BGWorker1 = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.BGWorker2 = new System.ComponentModel.BackgroundWorker();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.BGWorker3 = new System.ComponentModel.BackgroundWorker();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialFlatButton1
            // 
            this.materialFlatButton1.AutoSize = true;
            this.materialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton1.Depth = 0;
            this.materialFlatButton1.Location = new System.Drawing.Point(669, 68);
            this.materialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialFlatButton1.Name = "materialFlatButton1";
            this.materialFlatButton1.Primary = false;
            this.materialFlatButton1.Size = new System.Drawing.Size(116, 36);
            this.materialFlatButton1.TabIndex = 6;
            this.materialFlatButton1.Text = "Change Theme";
            this.materialFlatButton1.UseVisualStyleBackColor = true;
            this.materialFlatButton1.Click += new System.EventHandler(this.materialFlatButton1_Click);
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.BaseTabControl = this.materialTabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(-10, 108);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(796, 32);
            this.materialTabSelector1.TabIndex = 27;
            this.materialTabSelector1.Text = "materialTabSelector1";
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Controls.Add(this.tabPage4);
            this.materialTabControl1.Controls.Add(this.tabPage5);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Location = new System.Drawing.Point(12, 143);
            this.materialTabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(773, 623);
            this.materialTabControl1.TabIndex = 29;
            this.materialTabControl1.SelectedIndexChanged += new System.EventHandler(this.materialTabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.base64_Encrypt);
            this.tabPage1.Controls.Add(this.md5_Encrypt);
            this.tabPage1.Controls.Add(this.sha384_Encrypt);
            this.tabPage1.Controls.Add(this.sha512_Encrypt);
            this.tabPage1.Controls.Add(this.sha256_Encrypt);
            this.tabPage1.Controls.Add(this.sha1_Encrypt);
            this.tabPage1.Controls.Add(this.pictureBoxBlack);
            this.tabPage1.Controls.Add(this.pictureBoxWhite);
            this.tabPage1.Controls.Add(this.materialLabel4);
            this.tabPage1.Controls.Add(this.encrypt_txtBoxResult);
            this.tabPage1.Controls.Add(this.encrypt_btn_hash);
            this.tabPage1.Controls.Add(this.encrypt_inputRaw);
            this.tabPage1.Controls.Add(this.materialLabel1);
            this.tabPage1.Controls.Add(this.md5Reverse_Encrypt);
            this.tabPage1.Controls.Add(this.materialLabel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(765, 597);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ENCRYPTION";
            // 
            // base64_Encrypt
            // 
            this.base64_Encrypt.AutoSize = true;
            this.base64_Encrypt.Depth = 0;
            this.base64_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.base64_Encrypt.Location = new System.Drawing.Point(359, 98);
            this.base64_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.base64_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.base64_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.base64_Encrypt.Name = "base64_Encrypt";
            this.base64_Encrypt.Ripple = true;
            this.base64_Encrypt.Size = new System.Drawing.Size(75, 30);
            this.base64_Encrypt.TabIndex = 33;
            this.base64_Encrypt.TabStop = true;
            this.base64_Encrypt.Text = "Base64";
            this.base64_Encrypt.UseVisualStyleBackColor = true;
            // 
            // md5_Encrypt
            // 
            this.md5_Encrypt.AutoSize = true;
            this.md5_Encrypt.Depth = 0;
            this.md5_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5_Encrypt.Location = new System.Drawing.Point(16, 98);
            this.md5_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.md5_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5_Encrypt.Name = "md5_Encrypt";
            this.md5_Encrypt.Ripple = true;
            this.md5_Encrypt.Size = new System.Drawing.Size(58, 30);
            this.md5_Encrypt.TabIndex = 13;
            this.md5_Encrypt.Text = "MD5";
            this.md5_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha384_Encrypt
            // 
            this.sha384_Encrypt.AutoSize = true;
            this.sha384_Encrypt.Depth = 0;
            this.sha384_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha384_Encrypt.Location = new System.Drawing.Point(119, 128);
            this.sha384_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha384_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha384_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha384_Encrypt.Name = "sha384_Encrypt";
            this.sha384_Encrypt.Ripple = true;
            this.sha384_Encrypt.Size = new System.Drawing.Size(84, 30);
            this.sha384_Encrypt.TabIndex = 17;
            this.sha384_Encrypt.Text = "SHA-384";
            this.sha384_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha512_Encrypt
            // 
            this.sha512_Encrypt.AutoSize = true;
            this.sha512_Encrypt.Depth = 0;
            this.sha512_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha512_Encrypt.Location = new System.Drawing.Point(244, 128);
            this.sha512_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha512_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha512_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha512_Encrypt.Name = "sha512_Encrypt";
            this.sha512_Encrypt.Ripple = true;
            this.sha512_Encrypt.Size = new System.Drawing.Size(84, 30);
            this.sha512_Encrypt.TabIndex = 19;
            this.sha512_Encrypt.Text = "SHA-512";
            this.sha512_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha256_Encrypt
            // 
            this.sha256_Encrypt.AutoSize = true;
            this.sha256_Encrypt.Depth = 0;
            this.sha256_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha256_Encrypt.Location = new System.Drawing.Point(16, 128);
            this.sha256_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha256_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha256_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha256_Encrypt.Name = "sha256_Encrypt";
            this.sha256_Encrypt.Ripple = true;
            this.sha256_Encrypt.Size = new System.Drawing.Size(84, 30);
            this.sha256_Encrypt.TabIndex = 16;
            this.sha256_Encrypt.Text = "SHA-256";
            this.sha256_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha1_Encrypt
            // 
            this.sha1_Encrypt.AutoSize = true;
            this.sha1_Encrypt.Depth = 0;
            this.sha1_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha1_Encrypt.Location = new System.Drawing.Point(244, 98);
            this.sha1_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha1_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha1_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha1_Encrypt.Name = "sha1_Encrypt";
            this.sha1_Encrypt.Ripple = true;
            this.sha1_Encrypt.Size = new System.Drawing.Size(68, 30);
            this.sha1_Encrypt.TabIndex = 18;
            this.sha1_Encrypt.Text = "SHA-1";
            this.sha1_Encrypt.UseVisualStyleBackColor = true;
            // 
            // pictureBoxBlack
            // 
            this.pictureBoxBlack.Image = global::Hydra_Password_Tools.Properties.Resources.in_app;
            this.pictureBoxBlack.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxBlack.Name = "pictureBoxBlack";
            this.pictureBoxBlack.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxBlack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxBlack.TabIndex = 26;
            this.pictureBoxBlack.TabStop = false;
            // 
            // pictureBoxWhite
            // 
            this.pictureBoxWhite.Image = global::Hydra_Password_Tools.Properties.Resources.in_app_white1;
            this.pictureBoxWhite.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxWhite.Name = "pictureBoxWhite";
            this.pictureBoxWhite.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxWhite.TabIndex = 25;
            this.pictureBoxWhite.TabStop = false;
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(140, 582);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(52, 19);
            this.materialLabel4.TabIndex = 23;
            this.materialLabel4.Text = "Hash :";
            // 
            // encrypt_txtBoxResult
            // 
            this.encrypt_txtBoxResult.Depth = 0;
            this.encrypt_txtBoxResult.Hint = "";
            this.encrypt_txtBoxResult.Location = new System.Drawing.Point(199, 578);
            this.encrypt_txtBoxResult.MouseState = MaterialSkin.MouseState.HOVER;
            this.encrypt_txtBoxResult.Name = "encrypt_txtBoxResult";
            this.encrypt_txtBoxResult.PasswordChar = '\0';
            this.encrypt_txtBoxResult.SelectedText = "";
            this.encrypt_txtBoxResult.SelectionLength = 0;
            this.encrypt_txtBoxResult.SelectionStart = 0;
            this.encrypt_txtBoxResult.Size = new System.Drawing.Size(341, 23);
            this.encrypt_txtBoxResult.TabIndex = 22;
            this.encrypt_txtBoxResult.UseSystemPasswordChar = false;
            this.encrypt_txtBoxResult.TextChanged += new System.EventHandler(this.txtBoxResult_TextChanged);
            // 
            // encrypt_btn_hash
            // 
            this.encrypt_btn_hash.Depth = 0;
            this.encrypt_btn_hash.Location = new System.Drawing.Point(13, 565);
            this.encrypt_btn_hash.MouseState = MaterialSkin.MouseState.HOVER;
            this.encrypt_btn_hash.Name = "encrypt_btn_hash";
            this.encrypt_btn_hash.Primary = true;
            this.encrypt_btn_hash.Size = new System.Drawing.Size(111, 39);
            this.encrypt_btn_hash.TabIndex = 21;
            this.encrypt_btn_hash.Text = "Start Hash";
            this.encrypt_btn_hash.UseVisualStyleBackColor = true;
            this.encrypt_btn_hash.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // encrypt_inputRaw
            // 
            this.encrypt_inputRaw.Depth = 0;
            this.encrypt_inputRaw.Hint = "";
            this.encrypt_inputRaw.Location = new System.Drawing.Point(188, 18);
            this.encrypt_inputRaw.MouseState = MaterialSkin.MouseState.HOVER;
            this.encrypt_inputRaw.Name = "encrypt_inputRaw";
            this.encrypt_inputRaw.PasswordChar = '\0';
            this.encrypt_inputRaw.SelectedText = "";
            this.encrypt_inputRaw.SelectionLength = 0;
            this.encrypt_inputRaw.SelectionStart = 0;
            this.encrypt_inputRaw.Size = new System.Drawing.Size(352, 23);
            this.encrypt_inputRaw.TabIndex = 9;
            this.encrypt_inputRaw.UseSystemPasswordChar = false;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(16, 23);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(167, 19);
            this.materialLabel1.TabIndex = 8;
            this.materialLabel1.Text = "Enter your Passphrase :";
            // 
            // md5Reverse_Encrypt
            // 
            this.md5Reverse_Encrypt.AutoSize = true;
            this.md5Reverse_Encrypt.Depth = 0;
            this.md5Reverse_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5Reverse_Encrypt.Location = new System.Drawing.Point(119, 98);
            this.md5Reverse_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.md5Reverse_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5Reverse_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5Reverse_Encrypt.Name = "md5Reverse_Encrypt";
            this.md5Reverse_Encrypt.Ripple = true;
            this.md5Reverse_Encrypt.Size = new System.Drawing.Size(111, 30);
            this.md5Reverse_Encrypt.TabIndex = 15;
            this.md5Reverse_Encrypt.Text = "MD5 Reverse";
            this.md5Reverse_Encrypt.UseVisualStyleBackColor = true;
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(16, 66);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(175, 19);
            this.materialLabel2.TabIndex = 14;
            this.materialLabel2.Text = "Choose encryption type :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.decrypt_lbl_time);
            this.tabPage2.Controls.Add(this.materialLabel17);
            this.tabPage2.Controls.Add(this.decrypt_btn_stop);
            this.tabPage2.Controls.Add(this.decrypt_lbl_progress);
            this.tabPage2.Controls.Add(this.materialLabel5);
            this.tabPage2.Controls.Add(this.decrypt_lbl_status);
            this.tabPage2.Controls.Add(this.materialLabel10);
            this.tabPage2.Controls.Add(this.decrypt_btn_crack);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.pictureBoxWhite2);
            this.tabPage2.Controls.Add(this.sha256_algorithm);
            this.tabPage2.Controls.Add(this.sha384_algorithm);
            this.tabPage2.Controls.Add(this.base64_algorithm);
            this.tabPage2.Controls.Add(this.sha512_algorithm);
            this.tabPage2.Controls.Add(this.md5Reverse_algorithm);
            this.tabPage2.Controls.Add(this.sha1_algorithm);
            this.tabPage2.Controls.Add(this.decrypt_lbl_counted);
            this.tabPage2.Controls.Add(this.lbl_count);
            this.tabPage2.Controls.Add(this.decrypt_btn_reset);
            this.tabPage2.Controls.Add(this.decrypt_txtBox_outputBox);
            this.tabPage2.Controls.Add(this.materialLabel11);
            this.tabPage2.Controls.Add(this.materialLabel8);
            this.tabPage2.Controls.Add(this.decrypt_btn_browse);
            this.tabPage2.Controls.Add(this.lbl_list);
            this.tabPage2.Controls.Add(this.decrypt_lbl_path);
            this.tabPage2.Controls.Add(this.md5_algorithm);
            this.tabPage2.Controls.Add(this.materialLabel7);
            this.tabPage2.Controls.Add(this.decrypt_txtBox_inputHash);
            this.tabPage2.Controls.Add(this.materialLabel6);
            this.tabPage2.Controls.Add(this.pictureBoxBlack2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(765, 597);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "DECRYPTION";
            // 
            // decrypt_lbl_time
            // 
            this.decrypt_lbl_time.AutoSize = true;
            this.decrypt_lbl_time.Depth = 0;
            this.decrypt_lbl_time.Font = new System.Drawing.Font("Roboto", 11F);
            this.decrypt_lbl_time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.decrypt_lbl_time.Location = new System.Drawing.Point(114, 519);
            this.decrypt_lbl_time.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_lbl_time.Name = "decrypt_lbl_time";
            this.decrypt_lbl_time.Size = new System.Drawing.Size(65, 19);
            this.decrypt_lbl_time.TabIndex = 51;
            this.decrypt_lbl_time.Text = "00:00:00";
            // 
            // materialLabel17
            // 
            this.materialLabel17.AutoSize = true;
            this.materialLabel17.Depth = 0;
            this.materialLabel17.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel17.Location = new System.Drawing.Point(8, 519);
            this.materialLabel17.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel17.Name = "materialLabel17";
            this.materialLabel17.Size = new System.Drawing.Size(104, 19);
            this.materialLabel17.TabIndex = 50;
            this.materialLabel17.Text = "Elapsed time :";
            // 
            // decrypt_btn_stop
            // 
            this.decrypt_btn_stop.Depth = 0;
            this.decrypt_btn_stop.Location = new System.Drawing.Point(134, 439);
            this.decrypt_btn_stop.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_btn_stop.Name = "decrypt_btn_stop";
            this.decrypt_btn_stop.Primary = true;
            this.decrypt_btn_stop.Size = new System.Drawing.Size(76, 36);
            this.decrypt_btn_stop.TabIndex = 49;
            this.decrypt_btn_stop.Text = "Cancel";
            this.decrypt_btn_stop.UseVisualStyleBackColor = true;
            this.decrypt_btn_stop.Click += new System.EventHandler(this.materialRaisedButton3_Click_1);
            // 
            // decrypt_lbl_progress
            // 
            this.decrypt_lbl_progress.AutoSize = true;
            this.decrypt_lbl_progress.Depth = 0;
            this.decrypt_lbl_progress.Font = new System.Drawing.Font("Roboto", 11F);
            this.decrypt_lbl_progress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.decrypt_lbl_progress.Location = new System.Drawing.Point(88, 549);
            this.decrypt_lbl_progress.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_lbl_progress.Name = "decrypt_lbl_progress";
            this.decrypt_lbl_progress.Size = new System.Drawing.Size(32, 19);
            this.decrypt_lbl_progress.TabIndex = 48;
            this.decrypt_lbl_progress.Text = "0 %";
            // 
            // materialLabel5
            // 
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel5.Location = new System.Drawing.Point(8, 549);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(77, 19);
            this.materialLabel5.TabIndex = 47;
            this.materialLabel5.Text = "Progress :";
            // 
            // decrypt_lbl_status
            // 
            this.decrypt_lbl_status.AutoSize = true;
            this.decrypt_lbl_status.Depth = 0;
            this.decrypt_lbl_status.Font = new System.Drawing.Font("Roboto", 11F);
            this.decrypt_lbl_status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.decrypt_lbl_status.Location = new System.Drawing.Point(70, 491);
            this.decrypt_lbl_status.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_lbl_status.Name = "decrypt_lbl_status";
            this.decrypt_lbl_status.Size = new System.Drawing.Size(53, 19);
            this.decrypt_lbl_status.TabIndex = 37;
            this.decrypt_lbl_status.Text = "None !";
            // 
            // materialLabel10
            // 
            this.materialLabel10.AutoSize = true;
            this.materialLabel10.Depth = 0;
            this.materialLabel10.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel10.Location = new System.Drawing.Point(8, 491);
            this.materialLabel10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel10.Name = "materialLabel10";
            this.materialLabel10.Size = new System.Drawing.Size(60, 19);
            this.materialLabel10.TabIndex = 36;
            this.materialLabel10.Text = "Status :";
            // 
            // decrypt_btn_crack
            // 
            this.decrypt_btn_crack.Depth = 0;
            this.decrypt_btn_crack.Location = new System.Drawing.Point(10, 439);
            this.decrypt_btn_crack.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_btn_crack.Name = "decrypt_btn_crack";
            this.decrypt_btn_crack.Primary = true;
            this.decrypt_btn_crack.Size = new System.Drawing.Size(108, 36);
            this.decrypt_btn_crack.TabIndex = 38;
            this.decrypt_btn_crack.Text = "Start Crack";
            this.decrypt_btn_crack.UseVisualStyleBackColor = true;
            this.decrypt_btn_crack.Click += new System.EventHandler(this.materialRaisedButton4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox2.Controls.Add(this.bruteforce_radioBtn);
            this.groupBox2.Controls.Add(this.alphabetical_azCapital_radioBtn);
            this.groupBox2.Controls.Add(this.alphabetical_az_radioBtn);
            this.groupBox2.Controls.Add(this.numerical_radioBtn);
            this.groupBox2.Controls.Add(this.dictionary_radioBtn);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(10, 193);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(488, 95);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Crack Method";
            // 
            // bruteforce_radioBtn
            // 
            this.bruteforce_radioBtn.AutoSize = true;
            this.bruteforce_radioBtn.Depth = 0;
            this.bruteforce_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.bruteforce_radioBtn.Location = new System.Drawing.Point(6, 52);
            this.bruteforce_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.bruteforce_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.bruteforce_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.bruteforce_radioBtn.Name = "bruteforce_radioBtn";
            this.bruteforce_radioBtn.Ripple = true;
            this.bruteforce_radioBtn.Size = new System.Drawing.Size(97, 30);
            this.bruteforce_radioBtn.TabIndex = 8;
            this.bruteforce_radioBtn.TabStop = true;
            this.bruteforce_radioBtn.Text = "BruteForce";
            this.bruteforce_radioBtn.UseVisualStyleBackColor = true;
            // 
            // alphabetical_azCapital_radioBtn
            // 
            this.alphabetical_azCapital_radioBtn.AutoSize = true;
            this.alphabetical_azCapital_radioBtn.Depth = 0;
            this.alphabetical_azCapital_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.alphabetical_azCapital_radioBtn.Location = new System.Drawing.Point(314, 19);
            this.alphabetical_azCapital_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.alphabetical_azCapital_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.alphabetical_azCapital_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.alphabetical_azCapital_radioBtn.Name = "alphabetical_azCapital_radioBtn";
            this.alphabetical_azCapital_radioBtn.Ripple = true;
            this.alphabetical_azCapital_radioBtn.Size = new System.Drawing.Size(109, 30);
            this.alphabetical_azCapital_radioBtn.TabIndex = 7;
            this.alphabetical_azCapital_radioBtn.TabStop = true;
            this.alphabetical_azCapital_radioBtn.Text = "Alphabet A-Z";
            this.alphabetical_azCapital_radioBtn.UseVisualStyleBackColor = true;
            // 
            // alphabetical_az_radioBtn
            // 
            this.alphabetical_az_radioBtn.AutoSize = true;
            this.alphabetical_az_radioBtn.Depth = 0;
            this.alphabetical_az_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.alphabetical_az_radioBtn.Location = new System.Drawing.Point(164, 19);
            this.alphabetical_az_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.alphabetical_az_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.alphabetical_az_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.alphabetical_az_radioBtn.Name = "alphabetical_az_radioBtn";
            this.alphabetical_az_radioBtn.Ripple = true;
            this.alphabetical_az_radioBtn.Size = new System.Drawing.Size(110, 30);
            this.alphabetical_az_radioBtn.TabIndex = 6;
            this.alphabetical_az_radioBtn.TabStop = true;
            this.alphabetical_az_radioBtn.Text = "Alphabet  a-z";
            this.alphabetical_az_radioBtn.UseVisualStyleBackColor = true;
            // 
            // numerical_radioBtn
            // 
            this.numerical_radioBtn.AutoSize = true;
            this.numerical_radioBtn.Depth = 0;
            this.numerical_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.numerical_radioBtn.Location = new System.Drawing.Point(164, 52);
            this.numerical_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.numerical_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.numerical_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.numerical_radioBtn.Name = "numerical_radioBtn";
            this.numerical_radioBtn.Ripple = true;
            this.numerical_radioBtn.Size = new System.Drawing.Size(92, 30);
            this.numerical_radioBtn.TabIndex = 5;
            this.numerical_radioBtn.TabStop = true;
            this.numerical_radioBtn.Text = "Numerical";
            this.numerical_radioBtn.UseVisualStyleBackColor = true;
            // 
            // dictionary_radioBtn
            // 
            this.dictionary_radioBtn.AutoSize = true;
            this.dictionary_radioBtn.Depth = 0;
            this.dictionary_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.dictionary_radioBtn.Location = new System.Drawing.Point(6, 19);
            this.dictionary_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.dictionary_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.dictionary_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.dictionary_radioBtn.Name = "dictionary_radioBtn";
            this.dictionary_radioBtn.Ripple = true;
            this.dictionary_radioBtn.Size = new System.Drawing.Size(133, 30);
            this.dictionary_radioBtn.TabIndex = 4;
            this.dictionary_radioBtn.TabStop = true;
            this.dictionary_radioBtn.Text = "Dictionary attack";
            this.dictionary_radioBtn.UseVisualStyleBackColor = true;
            // 
            // pictureBoxWhite2
            // 
            this.pictureBoxWhite2.Image = global::Hydra_Password_Tools.Properties.Resources.in_app_white1;
            this.pictureBoxWhite2.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxWhite2.Name = "pictureBoxWhite2";
            this.pictureBoxWhite2.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxWhite2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxWhite2.TabIndex = 45;
            this.pictureBoxWhite2.TabStop = false;
            // 
            // sha256_algorithm
            // 
            this.sha256_algorithm.AutoSize = true;
            this.sha256_algorithm.Depth = 0;
            this.sha256_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha256_algorithm.Location = new System.Drawing.Point(10, 138);
            this.sha256_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha256_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha256_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha256_algorithm.Name = "sha256_algorithm";
            this.sha256_algorithm.Ripple = true;
            this.sha256_algorithm.Size = new System.Drawing.Size(84, 30);
            this.sha256_algorithm.TabIndex = 27;
            this.sha256_algorithm.TabStop = true;
            this.sha256_algorithm.Text = "SHA-256";
            this.sha256_algorithm.UseVisualStyleBackColor = true;
            // 
            // sha384_algorithm
            // 
            this.sha384_algorithm.AutoSize = true;
            this.sha384_algorithm.Depth = 0;
            this.sha384_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha384_algorithm.Location = new System.Drawing.Point(117, 138);
            this.sha384_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha384_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha384_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha384_algorithm.Name = "sha384_algorithm";
            this.sha384_algorithm.Ripple = true;
            this.sha384_algorithm.Size = new System.Drawing.Size(84, 30);
            this.sha384_algorithm.TabIndex = 29;
            this.sha384_algorithm.TabStop = true;
            this.sha384_algorithm.Text = "SHA-384";
            this.sha384_algorithm.UseVisualStyleBackColor = true;
            // 
            // base64_algorithm
            // 
            this.base64_algorithm.AutoSize = true;
            this.base64_algorithm.Depth = 0;
            this.base64_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.base64_algorithm.Location = new System.Drawing.Point(337, 108);
            this.base64_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.base64_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.base64_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.base64_algorithm.Name = "base64_algorithm";
            this.base64_algorithm.Ripple = true;
            this.base64_algorithm.Size = new System.Drawing.Size(75, 30);
            this.base64_algorithm.TabIndex = 31;
            this.base64_algorithm.TabStop = true;
            this.base64_algorithm.Text = "Base64";
            this.base64_algorithm.UseVisualStyleBackColor = true;
            this.base64_algorithm.CheckedChanged += new System.EventHandler(this.base64_algorithm_CheckedChanged);
            // 
            // sha512_algorithm
            // 
            this.sha512_algorithm.AutoSize = true;
            this.sha512_algorithm.Depth = 0;
            this.sha512_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha512_algorithm.Location = new System.Drawing.Point(237, 138);
            this.sha512_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha512_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha512_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha512_algorithm.Name = "sha512_algorithm";
            this.sha512_algorithm.Ripple = true;
            this.sha512_algorithm.Size = new System.Drawing.Size(84, 30);
            this.sha512_algorithm.TabIndex = 31;
            this.sha512_algorithm.TabStop = true;
            this.sha512_algorithm.Text = "SHA-512";
            this.sha512_algorithm.UseVisualStyleBackColor = true;
            // 
            // md5Reverse_algorithm
            // 
            this.md5Reverse_algorithm.AutoSize = true;
            this.md5Reverse_algorithm.Depth = 0;
            this.md5Reverse_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5Reverse_algorithm.Location = new System.Drawing.Point(117, 108);
            this.md5Reverse_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.md5Reverse_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5Reverse_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5Reverse_algorithm.Name = "md5Reverse_algorithm";
            this.md5Reverse_algorithm.Ripple = true;
            this.md5Reverse_algorithm.Size = new System.Drawing.Size(111, 30);
            this.md5Reverse_algorithm.TabIndex = 28;
            this.md5Reverse_algorithm.TabStop = true;
            this.md5Reverse_algorithm.Text = "MD5 Reverse";
            this.md5Reverse_algorithm.UseVisualStyleBackColor = true;
            // 
            // sha1_algorithm
            // 
            this.sha1_algorithm.AutoSize = true;
            this.sha1_algorithm.Depth = 0;
            this.sha1_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha1_algorithm.Location = new System.Drawing.Point(237, 108);
            this.sha1_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha1_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha1_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha1_algorithm.Name = "sha1_algorithm";
            this.sha1_algorithm.Ripple = true;
            this.sha1_algorithm.Size = new System.Drawing.Size(68, 30);
            this.sha1_algorithm.TabIndex = 30;
            this.sha1_algorithm.TabStop = true;
            this.sha1_algorithm.Text = "SHA-1";
            this.sha1_algorithm.UseVisualStyleBackColor = true;
            // 
            // decrypt_lbl_counted
            // 
            this.decrypt_lbl_counted.AutoSize = true;
            this.decrypt_lbl_counted.Depth = 0;
            this.decrypt_lbl_counted.Font = new System.Drawing.Font("Roboto", 11F);
            this.decrypt_lbl_counted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.decrypt_lbl_counted.Location = new System.Drawing.Point(167, 393);
            this.decrypt_lbl_counted.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.decrypt_lbl_counted.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_lbl_counted.Name = "decrypt_lbl_counted";
            this.decrypt_lbl_counted.Size = new System.Drawing.Size(17, 19);
            this.decrypt_lbl_counted.TabIndex = 44;
            this.decrypt_lbl_counted.Text = "0";
            // 
            // lbl_count
            // 
            this.lbl_count.AutoSize = true;
            this.lbl_count.Depth = 0;
            this.lbl_count.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_count.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_count.Location = new System.Drawing.Point(13, 393);
            this.lbl_count.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_count.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_count.Name = "lbl_count";
            this.lbl_count.Size = new System.Drawing.Size(155, 19);
            this.lbl_count.TabIndex = 43;
            this.lbl_count.Text = "Loaded passphrases :";
            // 
            // decrypt_btn_reset
            // 
            this.decrypt_btn_reset.Depth = 0;
            this.decrypt_btn_reset.Location = new System.Drawing.Point(408, 573);
            this.decrypt_btn_reset.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_btn_reset.Name = "decrypt_btn_reset";
            this.decrypt_btn_reset.Primary = true;
            this.decrypt_btn_reset.Size = new System.Drawing.Size(74, 29);
            this.decrypt_btn_reset.TabIndex = 42;
            this.decrypt_btn_reset.Text = "Reset";
            this.decrypt_btn_reset.UseVisualStyleBackColor = true;
            this.decrypt_btn_reset.Click += new System.EventHandler(this.materialRaisedButton6_Click);
            // 
            // decrypt_txtBox_outputBox
            // 
            this.decrypt_txtBox_outputBox.Depth = 0;
            this.decrypt_txtBox_outputBox.Hint = "";
            this.decrypt_txtBox_outputBox.Location = new System.Drawing.Point(108, 577);
            this.decrypt_txtBox_outputBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_txtBox_outputBox.Name = "decrypt_txtBox_outputBox";
            this.decrypt_txtBox_outputBox.PasswordChar = '\0';
            this.decrypt_txtBox_outputBox.SelectedText = "";
            this.decrypt_txtBox_outputBox.SelectionLength = 0;
            this.decrypt_txtBox_outputBox.SelectionStart = 0;
            this.decrypt_txtBox_outputBox.Size = new System.Drawing.Size(274, 23);
            this.decrypt_txtBox_outputBox.TabIndex = 40;
            this.decrypt_txtBox_outputBox.UseSystemPasswordChar = false;
            this.decrypt_txtBox_outputBox.TextChanged += new System.EventHandler(this.outputBox_TextChanged);
            // 
            // materialLabel11
            // 
            this.materialLabel11.AutoSize = true;
            this.materialLabel11.Depth = 0;
            this.materialLabel11.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel11.Location = new System.Drawing.Point(8, 581);
            this.materialLabel11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel11.Name = "materialLabel11";
            this.materialLabel11.Size = new System.Drawing.Size(95, 19);
            this.materialLabel11.TabIndex = 39;
            this.materialLabel11.Text = "Passphrase :";
            // 
            // materialLabel8
            // 
            this.materialLabel8.AutoSize = true;
            this.materialLabel8.Depth = 0;
            this.materialLabel8.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel8.Location = new System.Drawing.Point(13, 323);
            this.materialLabel8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel8.Name = "materialLabel8";
            this.materialLabel8.Size = new System.Drawing.Size(173, 19);
            this.materialLabel8.TabIndex = 32;
            this.materialLabel8.Text = "Browse passphrase list :";
            // 
            // decrypt_btn_browse
            // 
            this.decrypt_btn_browse.Depth = 0;
            this.decrypt_btn_browse.Location = new System.Drawing.Point(190, 315);
            this.decrypt_btn_browse.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_btn_browse.Name = "decrypt_btn_browse";
            this.decrypt_btn_browse.Primary = true;
            this.decrypt_btn_browse.Size = new System.Drawing.Size(83, 33);
            this.decrypt_btn_browse.TabIndex = 33;
            this.decrypt_btn_browse.Text = "Browse...";
            this.decrypt_btn_browse.UseVisualStyleBackColor = true;
            this.decrypt_btn_browse.Click += new System.EventHandler(this.materialRaisedButton3_Click);
            // 
            // lbl_list
            // 
            this.lbl_list.AutoSize = true;
            this.lbl_list.Depth = 0;
            this.lbl_list.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_list.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_list.Location = new System.Drawing.Point(13, 363);
            this.lbl_list.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_list.Name = "lbl_list";
            this.lbl_list.Size = new System.Drawing.Size(41, 19);
            this.lbl_list.TabIndex = 34;
            this.lbl_list.Text = "File :";
            // 
            // decrypt_lbl_path
            // 
            this.decrypt_lbl_path.AutoSize = true;
            this.decrypt_lbl_path.Depth = 0;
            this.decrypt_lbl_path.Font = new System.Drawing.Font("Roboto", 11F);
            this.decrypt_lbl_path.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.decrypt_lbl_path.Location = new System.Drawing.Point(52, 363);
            this.decrypt_lbl_path.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_lbl_path.Name = "decrypt_lbl_path";
            this.decrypt_lbl_path.Size = new System.Drawing.Size(53, 19);
            this.decrypt_lbl_path.TabIndex = 35;
            this.decrypt_lbl_path.Text = "None !";
            // 
            // md5_algorithm
            // 
            this.md5_algorithm.AutoSize = true;
            this.md5_algorithm.Depth = 0;
            this.md5_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5_algorithm.Location = new System.Drawing.Point(10, 108);
            this.md5_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.md5_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5_algorithm.Name = "md5_algorithm";
            this.md5_algorithm.Ripple = true;
            this.md5_algorithm.Size = new System.Drawing.Size(58, 30);
            this.md5_algorithm.TabIndex = 26;
            this.md5_algorithm.TabStop = true;
            this.md5_algorithm.Text = "MD5";
            this.md5_algorithm.UseVisualStyleBackColor = true;
            // 
            // materialLabel7
            // 
            this.materialLabel7.AutoSize = true;
            this.materialLabel7.Depth = 0;
            this.materialLabel7.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel7.Location = new System.Drawing.Point(5, 75);
            this.materialLabel7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel7.Name = "materialLabel7";
            this.materialLabel7.Size = new System.Drawing.Size(175, 19);
            this.materialLabel7.TabIndex = 25;
            this.materialLabel7.Text = "Choose decryption type :";
            // 
            // decrypt_txtBox_inputHash
            // 
            this.decrypt_txtBox_inputHash.Depth = 0;
            this.decrypt_txtBox_inputHash.Hint = "";
            this.decrypt_txtBox_inputHash.Location = new System.Drawing.Point(139, 23);
            this.decrypt_txtBox_inputHash.MouseState = MaterialSkin.MouseState.HOVER;
            this.decrypt_txtBox_inputHash.Name = "decrypt_txtBox_inputHash";
            this.decrypt_txtBox_inputHash.PasswordChar = '\0';
            this.decrypt_txtBox_inputHash.SelectedText = "";
            this.decrypt_txtBox_inputHash.SelectionLength = 0;
            this.decrypt_txtBox_inputHash.SelectionStart = 0;
            this.decrypt_txtBox_inputHash.Size = new System.Drawing.Size(359, 23);
            this.decrypt_txtBox_inputHash.TabIndex = 24;
            this.decrypt_txtBox_inputHash.UseSystemPasswordChar = false;
            // 
            // materialLabel6
            // 
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel6.Location = new System.Drawing.Point(5, 28);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(124, 19);
            this.materialLabel6.TabIndex = 23;
            this.materialLabel6.Text = "Enter your Hash :";
            // 
            // pictureBoxBlack2
            // 
            this.pictureBoxBlack2.Image = global::Hydra_Password_Tools.Properties.Resources.in_app;
            this.pictureBoxBlack2.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxBlack2.Name = "pictureBoxBlack2";
            this.pictureBoxBlack2.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxBlack2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxBlack2.TabIndex = 15;
            this.pictureBoxBlack2.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.identifier_btn_reset);
            this.tabPage3.Controls.Add(this.pictureBoxBlack3);
            this.tabPage3.Controls.Add(this.pictureBoxWhite3);
            this.tabPage3.Controls.Add(this.lbl_identify);
            this.tabPage3.Controls.Add(this.materialLabel13);
            this.tabPage3.Controls.Add(this.identifier_btn_identify);
            this.tabPage3.Controls.Add(this.txtBox_hashidnty);
            this.tabPage3.Controls.Add(this.materialLabel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(765, 597);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Hash Identifier";
            // 
            // identifier_btn_reset
            // 
            this.identifier_btn_reset.Depth = 0;
            this.identifier_btn_reset.Location = new System.Drawing.Point(653, 73);
            this.identifier_btn_reset.MouseState = MaterialSkin.MouseState.HOVER;
            this.identifier_btn_reset.Name = "identifier_btn_reset";
            this.identifier_btn_reset.Primary = true;
            this.identifier_btn_reset.Size = new System.Drawing.Size(98, 33);
            this.identifier_btn_reset.TabIndex = 29;
            this.identifier_btn_reset.Text = "Reset";
            this.identifier_btn_reset.UseVisualStyleBackColor = true;
            this.identifier_btn_reset.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // pictureBoxBlack3
            // 
            this.pictureBoxBlack3.Image = global::Hydra_Password_Tools.Properties.Resources.in_app;
            this.pictureBoxBlack3.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxBlack3.Name = "pictureBoxBlack3";
            this.pictureBoxBlack3.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxBlack3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxBlack3.TabIndex = 28;
            this.pictureBoxBlack3.TabStop = false;
            // 
            // pictureBoxWhite3
            // 
            this.pictureBoxWhite3.Image = global::Hydra_Password_Tools.Properties.Resources.in_app_white1;
            this.pictureBoxWhite3.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxWhite3.Name = "pictureBoxWhite3";
            this.pictureBoxWhite3.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxWhite3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxWhite3.TabIndex = 27;
            this.pictureBoxWhite3.TabStop = false;
            // 
            // lbl_identify
            // 
            this.lbl_identify.AutoSize = true;
            this.lbl_identify.Depth = 0;
            this.lbl_identify.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_identify.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_identify.Location = new System.Drawing.Point(134, 132);
            this.lbl_identify.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_identify.Name = "lbl_identify";
            this.lbl_identify.Size = new System.Drawing.Size(36, 19);
            this.lbl_identify.TabIndex = 5;
            this.lbl_identify.Text = "N/A";
            // 
            // materialLabel13
            // 
            this.materialLabel13.AutoSize = true;
            this.materialLabel13.Depth = 0;
            this.materialLabel13.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel13.Location = new System.Drawing.Point(15, 132);
            this.materialLabel13.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel13.Name = "materialLabel13";
            this.materialLabel13.Size = new System.Drawing.Size(120, 19);
            this.materialLabel13.TabIndex = 4;
            this.materialLabel13.Text = "Hash maybe be :";
            // 
            // identifier_btn_identify
            // 
            this.identifier_btn_identify.Depth = 0;
            this.identifier_btn_identify.Location = new System.Drawing.Point(18, 73);
            this.identifier_btn_identify.MouseState = MaterialSkin.MouseState.HOVER;
            this.identifier_btn_identify.Name = "identifier_btn_identify";
            this.identifier_btn_identify.Primary = true;
            this.identifier_btn_identify.Size = new System.Drawing.Size(619, 33);
            this.identifier_btn_identify.TabIndex = 3;
            this.identifier_btn_identify.Text = "Identify Hash";
            this.identifier_btn_identify.UseVisualStyleBackColor = true;
            this.identifier_btn_identify.Click += new System.EventHandler(this.Identify_Btn_Click);
            // 
            // txtBox_hashidnty
            // 
            this.txtBox_hashidnty.Depth = 0;
            this.txtBox_hashidnty.Hint = "";
            this.txtBox_hashidnty.Location = new System.Drawing.Point(141, 25);
            this.txtBox_hashidnty.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBox_hashidnty.Name = "txtBox_hashidnty";
            this.txtBox_hashidnty.PasswordChar = '\0';
            this.txtBox_hashidnty.SelectedText = "";
            this.txtBox_hashidnty.SelectionLength = 0;
            this.txtBox_hashidnty.SelectionStart = 0;
            this.txtBox_hashidnty.Size = new System.Drawing.Size(496, 23);
            this.txtBox_hashidnty.TabIndex = 2;
            this.txtBox_hashidnty.UseSystemPasswordChar = false;
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(11, 29);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(124, 19);
            this.materialLabel3.TabIndex = 1;
            this.materialLabel3.Text = "Enter your Hash :";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(765, 597);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "List generator";
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(417, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(331, 595);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Passphrase list";
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox3.Controls.Add(this.materialLabel19);
            this.groupBox3.Controls.Add(this.passgen_lbl_total);
            this.groupBox3.Controls.Add(this.passgen_lbl_time);
            this.groupBox3.Controls.Add(this.materialLabel27);
            this.groupBox3.Controls.Add(this.materialLabel28);
            this.groupBox3.Controls.Add(this.passgen_lbl_progress);
            this.groupBox3.Controls.Add(this.passgen_lbl_status);
            this.groupBox3.Controls.Add(this.materialLabel31);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(19, 401);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(294, 181);
            this.groupBox3.TabIndex = 49;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Information";
            // 
            // materialLabel19
            // 
            this.materialLabel19.AutoSize = true;
            this.materialLabel19.Depth = 0;
            this.materialLabel19.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel19.Location = new System.Drawing.Point(16, 26);
            this.materialLabel19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.materialLabel19.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel19.Name = "materialLabel19";
            this.materialLabel19.Size = new System.Drawing.Size(141, 19);
            this.materialLabel19.TabIndex = 68;
            this.materialLabel19.Text = "Total passphrases :";
            // 
            // passgen_lbl_total
            // 
            this.passgen_lbl_total.AutoSize = true;
            this.passgen_lbl_total.Depth = 0;
            this.passgen_lbl_total.Font = new System.Drawing.Font("Roboto", 11F);
            this.passgen_lbl_total.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passgen_lbl_total.Location = new System.Drawing.Point(156, 26);
            this.passgen_lbl_total.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.passgen_lbl_total.MouseState = MaterialSkin.MouseState.HOVER;
            this.passgen_lbl_total.Name = "passgen_lbl_total";
            this.passgen_lbl_total.Size = new System.Drawing.Size(17, 19);
            this.passgen_lbl_total.TabIndex = 69;
            this.passgen_lbl_total.Text = "0";
            // 
            // passgen_lbl_time
            // 
            this.passgen_lbl_time.AutoSize = true;
            this.passgen_lbl_time.Depth = 0;
            this.passgen_lbl_time.Font = new System.Drawing.Font("Roboto", 11F);
            this.passgen_lbl_time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passgen_lbl_time.Location = new System.Drawing.Point(122, 86);
            this.passgen_lbl_time.MouseState = MaterialSkin.MouseState.HOVER;
            this.passgen_lbl_time.Name = "passgen_lbl_time";
            this.passgen_lbl_time.Size = new System.Drawing.Size(65, 19);
            this.passgen_lbl_time.TabIndex = 67;
            this.passgen_lbl_time.Text = "00:00:00";
            // 
            // materialLabel27
            // 
            this.materialLabel27.AutoSize = true;
            this.materialLabel27.Depth = 0;
            this.materialLabel27.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel27.Location = new System.Drawing.Point(16, 86);
            this.materialLabel27.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel27.Name = "materialLabel27";
            this.materialLabel27.Size = new System.Drawing.Size(104, 19);
            this.materialLabel27.TabIndex = 66;
            this.materialLabel27.Text = "Elapsed time :";
            // 
            // materialLabel28
            // 
            this.materialLabel28.AutoSize = true;
            this.materialLabel28.Depth = 0;
            this.materialLabel28.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel28.Location = new System.Drawing.Point(16, 56);
            this.materialLabel28.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel28.Name = "materialLabel28";
            this.materialLabel28.Size = new System.Drawing.Size(60, 19);
            this.materialLabel28.TabIndex = 62;
            this.materialLabel28.Text = "Status :";
            // 
            // passgen_lbl_progress
            // 
            this.passgen_lbl_progress.AutoSize = true;
            this.passgen_lbl_progress.Depth = 0;
            this.passgen_lbl_progress.Font = new System.Drawing.Font("Roboto", 11F);
            this.passgen_lbl_progress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passgen_lbl_progress.Location = new System.Drawing.Point(98, 116);
            this.passgen_lbl_progress.MouseState = MaterialSkin.MouseState.HOVER;
            this.passgen_lbl_progress.Name = "passgen_lbl_progress";
            this.passgen_lbl_progress.Size = new System.Drawing.Size(32, 19);
            this.passgen_lbl_progress.TabIndex = 65;
            this.passgen_lbl_progress.Text = "0 %";
            // 
            // passgen_lbl_status
            // 
            this.passgen_lbl_status.AutoSize = true;
            this.passgen_lbl_status.Depth = 0;
            this.passgen_lbl_status.Font = new System.Drawing.Font("Roboto", 11F);
            this.passgen_lbl_status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passgen_lbl_status.Location = new System.Drawing.Point(78, 56);
            this.passgen_lbl_status.MouseState = MaterialSkin.MouseState.HOVER;
            this.passgen_lbl_status.Name = "passgen_lbl_status";
            this.passgen_lbl_status.Size = new System.Drawing.Size(53, 19);
            this.passgen_lbl_status.TabIndex = 63;
            this.passgen_lbl_status.Text = "None !";
            // 
            // materialLabel31
            // 
            this.materialLabel31.AutoSize = true;
            this.materialLabel31.Depth = 0;
            this.materialLabel31.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel31.Location = new System.Drawing.Point(16, 116);
            this.materialLabel31.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel31.Name = "materialLabel31";
            this.materialLabel31.Size = new System.Drawing.Size(77, 19);
            this.materialLabel31.TabIndex = 64;
            this.materialLabel31.Text = "Progress :";
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox4.Controls.Add(this.passgen_btn_gnrt);
            this.groupBox4.Controls.Add(this.passgen_btn_reset);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(19, 303);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(294, 87);
            this.groupBox4.TabIndex = 48;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Operation";
            // 
            // passgen_btn_gnrt
            // 
            this.passgen_btn_gnrt.Depth = 0;
            this.passgen_btn_gnrt.Location = new System.Drawing.Point(151, 32);
            this.passgen_btn_gnrt.Margin = new System.Windows.Forms.Padding(2);
            this.passgen_btn_gnrt.MouseState = MaterialSkin.MouseState.HOVER;
            this.passgen_btn_gnrt.Name = "passgen_btn_gnrt";
            this.passgen_btn_gnrt.Primary = true;
            this.passgen_btn_gnrt.Size = new System.Drawing.Size(131, 32);
            this.passgen_btn_gnrt.TabIndex = 19;
            this.passgen_btn_gnrt.Text = "Generate";
            this.passgen_btn_gnrt.UseVisualStyleBackColor = true;
            this.passgen_btn_gnrt.Click += new System.EventHandler(this.passgen_btn_gnrt_Click);
            // 
            // passgen_btn_reset
            // 
            this.passgen_btn_reset.Depth = 0;
            this.passgen_btn_reset.Location = new System.Drawing.Point(12, 32);
            this.passgen_btn_reset.Margin = new System.Windows.Forms.Padding(2);
            this.passgen_btn_reset.MouseState = MaterialSkin.MouseState.HOVER;
            this.passgen_btn_reset.Name = "passgen_btn_reset";
            this.passgen_btn_reset.Primary = true;
            this.passgen_btn_reset.Size = new System.Drawing.Size(131, 32);
            this.passgen_btn_reset.TabIndex = 20;
            this.passgen_btn_reset.Text = "Reset";
            this.passgen_btn_reset.UseVisualStyleBackColor = true;
            this.passgen_btn_reset.Click += new System.EventHandler(this.passgen_btn_reset_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox5.Controls.Add(this.txtBox_len_passlist);
            this.groupBox5.Controls.Add(this.materialLabel24);
            this.groupBox5.Controls.Add(this.txtBox_chars_passlist);
            this.groupBox5.Controls.Add(this.lbl_chars);
            this.groupBox5.Controls.Add(this.passlist_autosave);
            this.groupBox5.Controls.Add(this.custom_passphrase_passlist);
            this.groupBox5.Controls.Add(this.numeric_passlist);
            this.groupBox5.Controls.Add(this.alphabet_az_passlist);
            this.groupBox5.Controls.Add(this.materialLabel35);
            this.groupBox5.Controls.Add(this.alphabet_az_capital_passlist);
            this.groupBox5.Controls.Add(this.passphrase_passlist);
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox5.ForeColor = System.Drawing.Color.Black;
            this.groupBox5.Location = new System.Drawing.Point(19, 22);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(294, 272);
            this.groupBox5.TabIndex = 47;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Setting";
            // 
            // txtBox_len_passlist
            // 
            this.txtBox_len_passlist.Depth = 0;
            this.txtBox_len_passlist.Hint = "";
            this.txtBox_len_passlist.Location = new System.Drawing.Point(150, 155);
            this.txtBox_len_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBox_len_passlist.Name = "txtBox_len_passlist";
            this.txtBox_len_passlist.PasswordChar = '\0';
            this.txtBox_len_passlist.SelectedText = "";
            this.txtBox_len_passlist.SelectionLength = 0;
            this.txtBox_len_passlist.SelectionStart = 0;
            this.txtBox_len_passlist.Size = new System.Drawing.Size(75, 23);
            this.txtBox_len_passlist.TabIndex = 44;
            this.txtBox_len_passlist.UseSystemPasswordChar = false;
            this.txtBox_len_passlist.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBox_len_passlist_KeyPress);
            this.txtBox_len_passlist.TextChanged += new System.EventHandler(this.txtBox_len_passlist_TextChanged);
            // 
            // materialLabel24
            // 
            this.materialLabel24.AutoSize = true;
            this.materialLabel24.Depth = 0;
            this.materialLabel24.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel24.Location = new System.Drawing.Point(16, 155);
            this.materialLabel24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.materialLabel24.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel24.Name = "materialLabel24";
            this.materialLabel24.Size = new System.Drawing.Size(135, 19);
            this.materialLabel24.TabIndex = 43;
            this.materialLabel24.Text = "Length: From 0 To ";
            // 
            // txtBox_chars_passlist
            // 
            this.txtBox_chars_passlist.Depth = 0;
            this.txtBox_chars_passlist.Enabled = false;
            this.txtBox_chars_passlist.Hint = "";
            this.txtBox_chars_passlist.Location = new System.Drawing.Point(150, 189);
            this.txtBox_chars_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBox_chars_passlist.Name = "txtBox_chars_passlist";
            this.txtBox_chars_passlist.PasswordChar = '\0';
            this.txtBox_chars_passlist.SelectedText = "";
            this.txtBox_chars_passlist.SelectionLength = 0;
            this.txtBox_chars_passlist.SelectionStart = 0;
            this.txtBox_chars_passlist.Size = new System.Drawing.Size(132, 23);
            this.txtBox_chars_passlist.TabIndex = 42;
            this.txtBox_chars_passlist.UseSystemPasswordChar = false;
            this.txtBox_chars_passlist.TextChanged += new System.EventHandler(this.txtBox_chars_passlist_TextChanged);
            // 
            // lbl_chars
            // 
            this.lbl_chars.AutoSize = true;
            this.lbl_chars.Depth = 0;
            this.lbl_chars.Enabled = false;
            this.lbl_chars.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_chars.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_chars.Location = new System.Drawing.Point(18, 191);
            this.lbl_chars.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_chars.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_chars.Name = "lbl_chars";
            this.lbl_chars.Size = new System.Drawing.Size(123, 19);
            this.lbl_chars.TabIndex = 41;
            this.lbl_chars.Text = "Enter characters:";
            // 
            // passlist_autosave
            // 
            this.passlist_autosave.AutoSize = true;
            this.passlist_autosave.Depth = 0;
            this.passlist_autosave.Font = new System.Drawing.Font("Roboto", 10F);
            this.passlist_autosave.Location = new System.Drawing.Point(12, 223);
            this.passlist_autosave.Margin = new System.Windows.Forms.Padding(0);
            this.passlist_autosave.MouseLocation = new System.Drawing.Point(-1, -1);
            this.passlist_autosave.MouseState = MaterialSkin.MouseState.HOVER;
            this.passlist_autosave.Name = "passlist_autosave";
            this.passlist_autosave.Ripple = true;
            this.passlist_autosave.Size = new System.Drawing.Size(179, 30);
            this.passlist_autosave.TabIndex = 40;
            this.passlist_autosave.Text = "Auto save generated list";
            this.passlist_autosave.UseVisualStyleBackColor = true;
            // 
            // custom_passphrase_passlist
            // 
            this.custom_passphrase_passlist.AutoSize = true;
            this.custom_passphrase_passlist.Depth = 0;
            this.custom_passphrase_passlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.custom_passphrase_passlist.Location = new System.Drawing.Point(19, 112);
            this.custom_passphrase_passlist.Margin = new System.Windows.Forms.Padding(0);
            this.custom_passphrase_passlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.custom_passphrase_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.custom_passphrase_passlist.Name = "custom_passphrase_passlist";
            this.custom_passphrase_passlist.Ripple = true;
            this.custom_passphrase_passlist.Size = new System.Drawing.Size(152, 30);
            this.custom_passphrase_passlist.TabIndex = 35;
            this.custom_passphrase_passlist.TabStop = true;
            this.custom_passphrase_passlist.Text = "Custom passphrase";
            this.custom_passphrase_passlist.UseVisualStyleBackColor = true;
            this.custom_passphrase_passlist.CheckedChanged += new System.EventHandler(this.custom_passphrase_passlist_CheckedChanged);
            // 
            // numeric_passlist
            // 
            this.numeric_passlist.AutoSize = true;
            this.numeric_passlist.Depth = 0;
            this.numeric_passlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.numeric_passlist.Location = new System.Drawing.Point(19, 82);
            this.numeric_passlist.Margin = new System.Windows.Forms.Padding(0);
            this.numeric_passlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.numeric_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.numeric_passlist.Name = "numeric_passlist";
            this.numeric_passlist.Ripple = true;
            this.numeric_passlist.Size = new System.Drawing.Size(81, 30);
            this.numeric_passlist.TabIndex = 32;
            this.numeric_passlist.TabStop = true;
            this.numeric_passlist.Text = "Numeric";
            this.numeric_passlist.UseVisualStyleBackColor = true;
            this.numeric_passlist.CheckedChanged += new System.EventHandler(this.numeric_passlist_CheckedChanged);
            // 
            // alphabet_az_passlist
            // 
            this.alphabet_az_passlist.AutoSize = true;
            this.alphabet_az_passlist.Depth = 0;
            this.alphabet_az_passlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.alphabet_az_passlist.Location = new System.Drawing.Point(19, 51);
            this.alphabet_az_passlist.Margin = new System.Windows.Forms.Padding(0);
            this.alphabet_az_passlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.alphabet_az_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.alphabet_az_passlist.Name = "alphabet_az_passlist";
            this.alphabet_az_passlist.Ripple = true;
            this.alphabet_az_passlist.Size = new System.Drawing.Size(106, 30);
            this.alphabet_az_passlist.TabIndex = 30;
            this.alphabet_az_passlist.TabStop = true;
            this.alphabet_az_passlist.Text = "Alphabet a-z";
            this.alphabet_az_passlist.UseVisualStyleBackColor = true;
            this.alphabet_az_passlist.CheckedChanged += new System.EventHandler(this.alphabet_az_passlist_CheckedChanged);
            // 
            // materialLabel35
            // 
            this.materialLabel35.AutoSize = true;
            this.materialLabel35.Depth = 0;
            this.materialLabel35.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel35.Location = new System.Drawing.Point(18, 28);
            this.materialLabel35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.materialLabel35.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel35.Name = "materialLabel35";
            this.materialLabel35.Size = new System.Drawing.Size(207, 19);
            this.materialLabel35.TabIndex = 36;
            this.materialLabel35.Text = "Choose passphrase list type :";
            // 
            // alphabet_az_capital_passlist
            // 
            this.alphabet_az_capital_passlist.AutoSize = true;
            this.alphabet_az_capital_passlist.Depth = 0;
            this.alphabet_az_capital_passlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.alphabet_az_capital_passlist.Location = new System.Drawing.Point(150, 51);
            this.alphabet_az_capital_passlist.Margin = new System.Windows.Forms.Padding(0);
            this.alphabet_az_capital_passlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.alphabet_az_capital_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.alphabet_az_capital_passlist.Name = "alphabet_az_capital_passlist";
            this.alphabet_az_capital_passlist.Ripple = true;
            this.alphabet_az_capital_passlist.Size = new System.Drawing.Size(109, 30);
            this.alphabet_az_capital_passlist.TabIndex = 31;
            this.alphabet_az_capital_passlist.TabStop = true;
            this.alphabet_az_capital_passlist.Text = "Alphabet A-Z";
            this.alphabet_az_capital_passlist.UseVisualStyleBackColor = true;
            this.alphabet_az_capital_passlist.CheckedChanged += new System.EventHandler(this.alphabet_az_capital_passlist_CheckedChanged);
            // 
            // passphrase_passlist
            // 
            this.passphrase_passlist.AutoSize = true;
            this.passphrase_passlist.Depth = 0;
            this.passphrase_passlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.passphrase_passlist.Location = new System.Drawing.Point(150, 82);
            this.passphrase_passlist.Margin = new System.Windows.Forms.Padding(0);
            this.passphrase_passlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.passphrase_passlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.passphrase_passlist.Name = "passphrase_passlist";
            this.passphrase_passlist.Ripple = true;
            this.passphrase_passlist.Size = new System.Drawing.Size(101, 30);
            this.passphrase_passlist.TabIndex = 33;
            this.passphrase_passlist.TabStop = true;
            this.passphrase_passlist.Text = "Passphrase";
            this.passphrase_passlist.UseVisualStyleBackColor = true;
            this.passphrase_passlist.CheckedChanged += new System.EventHandler(this.passphrase_passlist_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox6.Controls.Add(this.groupBox9);
            this.groupBox6.Controls.Add(this.groupBox8);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox6.Location = new System.Drawing.Point(16, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(331, 595);
            this.groupBox6.TabIndex = 63;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Hash list";
            // 
            // groupBox9
            // 
            this.groupBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox9.Controls.Add(this.materialLabel22);
            this.groupBox9.Controls.Add(this.lstgen_lbl_path);
            this.groupBox9.Controls.Add(this.materialLabel25);
            this.groupBox9.Controls.Add(this.lstgen_lbl_time);
            this.groupBox9.Controls.Add(this.lstgen_lbl_counted);
            this.groupBox9.Controls.Add(this.materialLabel32);
            this.groupBox9.Controls.Add(this.materialLabel33);
            this.groupBox9.Controls.Add(this.lstgen_lbl_progress);
            this.groupBox9.Controls.Add(this.lstgen_lbl_status);
            this.groupBox9.Controls.Add(this.materialLabel36);
            this.groupBox9.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox9.Location = new System.Drawing.Point(19, 401);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(294, 181);
            this.groupBox9.TabIndex = 49;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Information";
            // 
            // materialLabel22
            // 
            this.materialLabel22.AutoSize = true;
            this.materialLabel22.Depth = 0;
            this.materialLabel22.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel22.Location = new System.Drawing.Point(18, 26);
            this.materialLabel22.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel22.Name = "materialLabel22";
            this.materialLabel22.Size = new System.Drawing.Size(41, 19);
            this.materialLabel22.TabIndex = 58;
            this.materialLabel22.Text = "File :";
            // 
            // lstgen_lbl_path
            // 
            this.lstgen_lbl_path.AutoSize = true;
            this.lstgen_lbl_path.Depth = 0;
            this.lstgen_lbl_path.Font = new System.Drawing.Font("Roboto", 11F);
            this.lstgen_lbl_path.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lstgen_lbl_path.Location = new System.Drawing.Point(57, 26);
            this.lstgen_lbl_path.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_lbl_path.Name = "lstgen_lbl_path";
            this.lstgen_lbl_path.Size = new System.Drawing.Size(53, 19);
            this.lstgen_lbl_path.TabIndex = 59;
            this.lstgen_lbl_path.Text = "None !";
            // 
            // materialLabel25
            // 
            this.materialLabel25.AutoSize = true;
            this.materialLabel25.Depth = 0;
            this.materialLabel25.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel25.Location = new System.Drawing.Point(18, 56);
            this.materialLabel25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.materialLabel25.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel25.Name = "materialLabel25";
            this.materialLabel25.Size = new System.Drawing.Size(155, 19);
            this.materialLabel25.TabIndex = 60;
            this.materialLabel25.Text = "Loaded passphrases :";
            // 
            // lstgen_lbl_time
            // 
            this.lstgen_lbl_time.AutoSize = true;
            this.lstgen_lbl_time.Depth = 0;
            this.lstgen_lbl_time.Font = new System.Drawing.Font("Roboto", 11F);
            this.lstgen_lbl_time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lstgen_lbl_time.Location = new System.Drawing.Point(124, 118);
            this.lstgen_lbl_time.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_lbl_time.Name = "lstgen_lbl_time";
            this.lstgen_lbl_time.Size = new System.Drawing.Size(65, 19);
            this.lstgen_lbl_time.TabIndex = 67;
            this.lstgen_lbl_time.Text = "00:00:00";
            // 
            // lstgen_lbl_counted
            // 
            this.lstgen_lbl_counted.AutoSize = true;
            this.lstgen_lbl_counted.Depth = 0;
            this.lstgen_lbl_counted.Font = new System.Drawing.Font("Roboto", 11F);
            this.lstgen_lbl_counted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lstgen_lbl_counted.Location = new System.Drawing.Point(172, 56);
            this.lstgen_lbl_counted.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lstgen_lbl_counted.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_lbl_counted.Name = "lstgen_lbl_counted";
            this.lstgen_lbl_counted.Size = new System.Drawing.Size(17, 19);
            this.lstgen_lbl_counted.TabIndex = 61;
            this.lstgen_lbl_counted.Text = "0";
            // 
            // materialLabel32
            // 
            this.materialLabel32.AutoSize = true;
            this.materialLabel32.Depth = 0;
            this.materialLabel32.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel32.Location = new System.Drawing.Point(18, 118);
            this.materialLabel32.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel32.Name = "materialLabel32";
            this.materialLabel32.Size = new System.Drawing.Size(104, 19);
            this.materialLabel32.TabIndex = 66;
            this.materialLabel32.Text = "Elapsed time :";
            // 
            // materialLabel33
            // 
            this.materialLabel33.AutoSize = true;
            this.materialLabel33.Depth = 0;
            this.materialLabel33.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel33.Location = new System.Drawing.Point(18, 88);
            this.materialLabel33.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel33.Name = "materialLabel33";
            this.materialLabel33.Size = new System.Drawing.Size(60, 19);
            this.materialLabel33.TabIndex = 62;
            this.materialLabel33.Text = "Status :";
            // 
            // lstgen_lbl_progress
            // 
            this.lstgen_lbl_progress.AutoSize = true;
            this.lstgen_lbl_progress.Depth = 0;
            this.lstgen_lbl_progress.Font = new System.Drawing.Font("Roboto", 11F);
            this.lstgen_lbl_progress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lstgen_lbl_progress.Location = new System.Drawing.Point(100, 148);
            this.lstgen_lbl_progress.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_lbl_progress.Name = "lstgen_lbl_progress";
            this.lstgen_lbl_progress.Size = new System.Drawing.Size(32, 19);
            this.lstgen_lbl_progress.TabIndex = 65;
            this.lstgen_lbl_progress.Text = "0 %";
            // 
            // lstgen_lbl_status
            // 
            this.lstgen_lbl_status.AutoSize = true;
            this.lstgen_lbl_status.Depth = 0;
            this.lstgen_lbl_status.Font = new System.Drawing.Font("Roboto", 11F);
            this.lstgen_lbl_status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lstgen_lbl_status.Location = new System.Drawing.Point(80, 88);
            this.lstgen_lbl_status.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_lbl_status.Name = "lstgen_lbl_status";
            this.lstgen_lbl_status.Size = new System.Drawing.Size(53, 19);
            this.lstgen_lbl_status.TabIndex = 63;
            this.lstgen_lbl_status.Text = "None !";
            // 
            // materialLabel36
            // 
            this.materialLabel36.AutoSize = true;
            this.materialLabel36.Depth = 0;
            this.materialLabel36.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel36.Location = new System.Drawing.Point(18, 148);
            this.materialLabel36.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel36.Name = "materialLabel36";
            this.materialLabel36.Size = new System.Drawing.Size(77, 19);
            this.materialLabel36.TabIndex = 64;
            this.materialLabel36.Text = "Progress :";
            // 
            // groupBox8
            // 
            this.groupBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox8.Controls.Add(this.lstgen_btn_gnrt);
            this.groupBox8.Controls.Add(this.lstgen_btn_reset);
            this.groupBox8.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox8.Location = new System.Drawing.Point(19, 303);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(294, 87);
            this.groupBox8.TabIndex = 48;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Operation";
            // 
            // lstgen_btn_gnrt
            // 
            this.lstgen_btn_gnrt.Depth = 0;
            this.lstgen_btn_gnrt.Location = new System.Drawing.Point(151, 32);
            this.lstgen_btn_gnrt.Margin = new System.Windows.Forms.Padding(2);
            this.lstgen_btn_gnrt.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_btn_gnrt.Name = "lstgen_btn_gnrt";
            this.lstgen_btn_gnrt.Primary = true;
            this.lstgen_btn_gnrt.Size = new System.Drawing.Size(131, 32);
            this.lstgen_btn_gnrt.TabIndex = 19;
            this.lstgen_btn_gnrt.Text = "Generate";
            this.lstgen_btn_gnrt.UseVisualStyleBackColor = true;
            this.lstgen_btn_gnrt.Click += new System.EventHandler(this.lstgen_btn_gnrt_Click_1);
            // 
            // lstgen_btn_reset
            // 
            this.lstgen_btn_reset.Depth = 0;
            this.lstgen_btn_reset.Location = new System.Drawing.Point(12, 32);
            this.lstgen_btn_reset.Margin = new System.Windows.Forms.Padding(2);
            this.lstgen_btn_reset.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_btn_reset.Name = "lstgen_btn_reset";
            this.lstgen_btn_reset.Primary = true;
            this.lstgen_btn_reset.Size = new System.Drawing.Size(131, 32);
            this.lstgen_btn_reset.TabIndex = 20;
            this.lstgen_btn_reset.Text = "Reset";
            this.lstgen_btn_reset.UseVisualStyleBackColor = true;
            this.lstgen_btn_reset.Click += new System.EventHandler(this.lstgen_btn_reset_Click_1);
            // 
            // groupBox7
            // 
            this.groupBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox7.Controls.Add(this.hashlist_autosave);
            this.groupBox7.Controls.Add(this.base64_hashlist);
            this.groupBox7.Controls.Add(this.materialLabel18);
            this.groupBox7.Controls.Add(this.sha384_hashlist);
            this.groupBox7.Controls.Add(this.lstgen_btn_browse);
            this.groupBox7.Controls.Add(this.sha1_hashlist);
            this.groupBox7.Controls.Add(this.sha512_hashlist);
            this.groupBox7.Controls.Add(this.md5_hashlist);
            this.groupBox7.Controls.Add(this.materialLabel20);
            this.groupBox7.Controls.Add(this.md5Reverse_hashlist);
            this.groupBox7.Controls.Add(this.sha256_hashlist);
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox7.ForeColor = System.Drawing.Color.Black;
            this.groupBox7.Location = new System.Drawing.Point(19, 22);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(294, 272);
            this.groupBox7.TabIndex = 47;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Setting";
            // 
            // hashlist_autosave
            // 
            this.hashlist_autosave.AutoSize = true;
            this.hashlist_autosave.Depth = 0;
            this.hashlist_autosave.Font = new System.Drawing.Font("Roboto", 10F);
            this.hashlist_autosave.Location = new System.Drawing.Point(12, 223);
            this.hashlist_autosave.Margin = new System.Windows.Forms.Padding(0);
            this.hashlist_autosave.MouseLocation = new System.Drawing.Point(-1, -1);
            this.hashlist_autosave.MouseState = MaterialSkin.MouseState.HOVER;
            this.hashlist_autosave.Name = "hashlist_autosave";
            this.hashlist_autosave.Ripple = true;
            this.hashlist_autosave.Size = new System.Drawing.Size(179, 30);
            this.hashlist_autosave.TabIndex = 40;
            this.hashlist_autosave.Text = "Auto save generated list";
            this.hashlist_autosave.UseVisualStyleBackColor = true;
            // 
            // base64_hashlist
            // 
            this.base64_hashlist.AutoSize = true;
            this.base64_hashlist.Depth = 0;
            this.base64_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.base64_hashlist.Location = new System.Drawing.Point(21, 179);
            this.base64_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.base64_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.base64_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.base64_hashlist.Name = "base64_hashlist";
            this.base64_hashlist.Ripple = true;
            this.base64_hashlist.Size = new System.Drawing.Size(75, 30);
            this.base64_hashlist.TabIndex = 39;
            this.base64_hashlist.TabStop = true;
            this.base64_hashlist.Text = "Base64";
            this.base64_hashlist.UseVisualStyleBackColor = true;
            // 
            // materialLabel18
            // 
            this.materialLabel18.AutoSize = true;
            this.materialLabel18.Depth = 0;
            this.materialLabel18.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel18.Location = new System.Drawing.Point(16, 28);
            this.materialLabel18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.materialLabel18.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel18.Name = "materialLabel18";
            this.materialLabel18.Size = new System.Drawing.Size(173, 19);
            this.materialLabel18.TabIndex = 37;
            this.materialLabel18.Text = "Browse passphrase list :";
            // 
            // sha384_hashlist
            // 
            this.sha384_hashlist.AutoSize = true;
            this.sha384_hashlist.Depth = 0;
            this.sha384_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha384_hashlist.Location = new System.Drawing.Point(21, 149);
            this.sha384_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.sha384_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha384_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha384_hashlist.Name = "sha384_hashlist";
            this.sha384_hashlist.Ripple = true;
            this.sha384_hashlist.Size = new System.Drawing.Size(84, 30);
            this.sha384_hashlist.TabIndex = 35;
            this.sha384_hashlist.TabStop = true;
            this.sha384_hashlist.Text = "SHA-384";
            this.sha384_hashlist.UseVisualStyleBackColor = true;
            // 
            // lstgen_btn_browse
            // 
            this.lstgen_btn_browse.Depth = 0;
            this.lstgen_btn_browse.Location = new System.Drawing.Point(197, 21);
            this.lstgen_btn_browse.Margin = new System.Windows.Forms.Padding(2);
            this.lstgen_btn_browse.MouseState = MaterialSkin.MouseState.HOVER;
            this.lstgen_btn_browse.Name = "lstgen_btn_browse";
            this.lstgen_btn_browse.Primary = true;
            this.lstgen_btn_browse.Size = new System.Drawing.Size(84, 32);
            this.lstgen_btn_browse.TabIndex = 38;
            this.lstgen_btn_browse.Text = "Browse...";
            this.lstgen_btn_browse.UseVisualStyleBackColor = true;
            this.lstgen_btn_browse.Click += new System.EventHandler(this.lstgen_btn_browse_Click_1);
            // 
            // sha1_hashlist
            // 
            this.sha1_hashlist.AutoSize = true;
            this.sha1_hashlist.Depth = 0;
            this.sha1_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha1_hashlist.Location = new System.Drawing.Point(21, 119);
            this.sha1_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.sha1_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha1_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha1_hashlist.Name = "sha1_hashlist";
            this.sha1_hashlist.Ripple = true;
            this.sha1_hashlist.Size = new System.Drawing.Size(68, 30);
            this.sha1_hashlist.TabIndex = 32;
            this.sha1_hashlist.TabStop = true;
            this.sha1_hashlist.Text = "SHA-1";
            this.sha1_hashlist.UseVisualStyleBackColor = true;
            // 
            // sha512_hashlist
            // 
            this.sha512_hashlist.AutoSize = true;
            this.sha512_hashlist.Depth = 0;
            this.sha512_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha512_hashlist.Location = new System.Drawing.Point(152, 149);
            this.sha512_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.sha512_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha512_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha512_hashlist.Name = "sha512_hashlist";
            this.sha512_hashlist.Ripple = true;
            this.sha512_hashlist.Size = new System.Drawing.Size(84, 30);
            this.sha512_hashlist.TabIndex = 34;
            this.sha512_hashlist.TabStop = true;
            this.sha512_hashlist.Text = "SHA-512";
            this.sha512_hashlist.UseVisualStyleBackColor = true;
            // 
            // md5_hashlist
            // 
            this.md5_hashlist.AutoSize = true;
            this.md5_hashlist.Depth = 0;
            this.md5_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5_hashlist.Location = new System.Drawing.Point(21, 89);
            this.md5_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.md5_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5_hashlist.Name = "md5_hashlist";
            this.md5_hashlist.Ripple = true;
            this.md5_hashlist.Size = new System.Drawing.Size(58, 30);
            this.md5_hashlist.TabIndex = 30;
            this.md5_hashlist.TabStop = true;
            this.md5_hashlist.Text = "MD5";
            this.md5_hashlist.UseVisualStyleBackColor = true;
            // 
            // materialLabel20
            // 
            this.materialLabel20.AutoSize = true;
            this.materialLabel20.Depth = 0;
            this.materialLabel20.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel20.Location = new System.Drawing.Point(22, 71);
            this.materialLabel20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.materialLabel20.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel20.Name = "materialLabel20";
            this.materialLabel20.Size = new System.Drawing.Size(175, 19);
            this.materialLabel20.TabIndex = 36;
            this.materialLabel20.Text = "Choose encryption type :";
            // 
            // md5Reverse_hashlist
            // 
            this.md5Reverse_hashlist.AutoSize = true;
            this.md5Reverse_hashlist.Depth = 0;
            this.md5Reverse_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5Reverse_hashlist.Location = new System.Drawing.Point(152, 89);
            this.md5Reverse_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.md5Reverse_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5Reverse_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5Reverse_hashlist.Name = "md5Reverse_hashlist";
            this.md5Reverse_hashlist.Ripple = true;
            this.md5Reverse_hashlist.Size = new System.Drawing.Size(111, 30);
            this.md5Reverse_hashlist.TabIndex = 31;
            this.md5Reverse_hashlist.TabStop = true;
            this.md5Reverse_hashlist.Text = "MD5 Reverse";
            this.md5Reverse_hashlist.UseVisualStyleBackColor = true;
            // 
            // sha256_hashlist
            // 
            this.sha256_hashlist.AutoSize = true;
            this.sha256_hashlist.Depth = 0;
            this.sha256_hashlist.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha256_hashlist.Location = new System.Drawing.Point(152, 119);
            this.sha256_hashlist.Margin = new System.Windows.Forms.Padding(0);
            this.sha256_hashlist.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha256_hashlist.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha256_hashlist.Name = "sha256_hashlist";
            this.sha256_hashlist.Ripple = true;
            this.sha256_hashlist.Size = new System.Drawing.Size(84, 30);
            this.sha256_hashlist.TabIndex = 33;
            this.sha256_hashlist.TabStop = true;
            this.sha256_hashlist.Text = "SHA-256";
            this.sha256_hashlist.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.materialLabel14);
            this.tabPage5.Controls.Add(this.materialLabel12);
            this.tabPage5.Controls.Add(this.linkLabel1);
            this.tabPage5.Controls.Add(this.materialLabel9);
            this.tabPage5.Controls.Add(this.materialLabel16);
            this.tabPage5.Controls.Add(this.materialLabel15);
            this.tabPage5.Controls.Add(this.linkLabel2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(765, 597);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "About";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // materialLabel14
            // 
            this.materialLabel14.AutoSize = true;
            this.materialLabel14.Depth = 0;
            this.materialLabel14.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel14.Location = new System.Drawing.Point(6, 201);
            this.materialLabel14.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel14.Name = "materialLabel14";
            this.materialLabel14.Size = new System.Drawing.Size(248, 19);
            this.materialLabel14.TabIndex = 70;
            this.materialLabel14.Text = "Email : Alisafi.Engineer@gmail.com";
            // 
            // materialLabel12
            // 
            this.materialLabel12.AutoSize = true;
            this.materialLabel12.Depth = 0;
            this.materialLabel12.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel12.Location = new System.Drawing.Point(5, 122);
            this.materialLabel12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel12.Name = "materialLabel12";
            this.materialLabel12.Size = new System.Drawing.Size(76, 19);
            this.materialLabel12.TabIndex = 69;
            this.materialLabel12.Text = "Telegram:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.linkLabel1.Location = new System.Drawing.Point(69, 158);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(248, 20);
            this.linkLabel1.TabIndex = 68;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://github.com/AliSafiEngineer";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // materialLabel9
            // 
            this.materialLabel9.AutoSize = true;
            this.materialLabel9.Depth = 0;
            this.materialLabel9.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel9.Location = new System.Drawing.Point(6, 161);
            this.materialLabel9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel9.Name = "materialLabel9";
            this.materialLabel9.Size = new System.Drawing.Size(67, 19);
            this.materialLabel9.TabIndex = 67;
            this.materialLabel9.Text = "GitHub : ";
            // 
            // materialLabel16
            // 
            this.materialLabel16.AutoSize = true;
            this.materialLabel16.Depth = 0;
            this.materialLabel16.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel16.Location = new System.Drawing.Point(6, 87);
            this.materialLabel16.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel16.Name = "materialLabel16";
            this.materialLabel16.Size = new System.Drawing.Size(138, 19);
            this.materialLabel16.TabIndex = 66;
            this.materialLabel16.Text = "Powered by Ali Safi";
            // 
            // materialLabel15
            // 
            this.materialLabel15.AutoSize = true;
            this.materialLabel15.Depth = 0;
            this.materialLabel15.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel15.Location = new System.Drawing.Point(6, 17);
            this.materialLabel15.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel15.Name = "materialLabel15";
            this.materialLabel15.Size = new System.Drawing.Size(258, 57);
            this.materialLabel15.TabIndex = 65;
            this.materialLabel15.Text = "About :\r\n\r\nHydra Krypto Tools Copyright © 2020";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.linkLabel2.Location = new System.Drawing.Point(79, 120);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(80, 20);
            this.linkLabel2.TabIndex = 64;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "@AliDesu";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // BGWorker1
            // 
            this.BGWorker1.WorkerReportsProgress = true;
            this.BGWorker1.WorkerSupportsCancellation = true;
            this.BGWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BGWorker_DoWork);
            this.BGWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.BGWorker_RunWorkerCompleted);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // BGWorker2
            // 
            this.BGWorker2.WorkerReportsProgress = true;
            this.BGWorker2.WorkerSupportsCancellation = true;
            this.BGWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BGWorker2_DoWork);
            this.BGWorker2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.BGWorker2_RunWorkerCompleted);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // BGWorker3
            // 
            this.BGWorker3.WorkerReportsProgress = true;
            this.BGWorker3.WorkerSupportsCancellation = true;
            this.BGWorker3.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BGWorker3_DoWork);
            this.BGWorker3.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.BGWorker3_RunWorkerCompleted);
            // 
            // timer3
            // 
            this.timer3.Enabled = true;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Main
            // 
            this.AcceptButton = this.encrypt_btn_hash;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 768);
            this.Controls.Add(this.materialTabControl1);
            this.Controls.Add(this.materialTabSelector1);
            this.Controls.Add(this.materialFlatButton1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Hydra Krypto Tools v1.9 - Powered by Ali Safi";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton1;
        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private MaterialSkin.Controls.MaterialRadioButton base64_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton md5_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha384_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha512_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha256_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha1_Encrypt;
        private System.Windows.Forms.PictureBox pictureBoxBlack;
        private System.Windows.Forms.PictureBox pictureBoxWhite;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialSingleLineTextField encrypt_txtBoxResult;
        private MaterialSkin.Controls.MaterialRaisedButton encrypt_btn_hash;
        private MaterialSkin.Controls.MaterialSingleLineTextField encrypt_inputRaw;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialRadioButton md5Reverse_Encrypt;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBoxWhite2;
        private MaterialSkin.Controls.MaterialRadioButton sha256_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton sha384_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton base64_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton sha512_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton md5Reverse_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton sha1_algorithm;
        private MaterialSkin.Controls.MaterialLabel lbl_count;
        private MaterialSkin.Controls.MaterialRaisedButton decrypt_btn_reset;
        private MaterialSkin.Controls.MaterialSingleLineTextField decrypt_txtBox_outputBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel11;
        private MaterialSkin.Controls.MaterialLabel materialLabel8;
        private MaterialSkin.Controls.MaterialRaisedButton decrypt_btn_browse;
        private MaterialSkin.Controls.MaterialRaisedButton decrypt_btn_crack;
        private MaterialSkin.Controls.MaterialLabel lbl_list;
        private MaterialSkin.Controls.MaterialLabel materialLabel10;
        private MaterialSkin.Controls.MaterialLabel decrypt_lbl_path;
        private MaterialSkin.Controls.MaterialLabel decrypt_lbl_status;
        private MaterialSkin.Controls.MaterialRadioButton md5_algorithm;
        private MaterialSkin.Controls.MaterialLabel materialLabel7;
        private MaterialSkin.Controls.MaterialSingleLineTextField decrypt_txtBox_inputHash;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private System.Windows.Forms.PictureBox pictureBoxBlack2;
        private System.ComponentModel.BackgroundWorker BGWorker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private MaterialSkin.Controls.MaterialRadioButton alphabetical_azCapital_radioBtn;
        private MaterialSkin.Controls.MaterialRadioButton alphabetical_az_radioBtn;
        private MaterialSkin.Controls.MaterialRadioButton numerical_radioBtn;
        private MaterialSkin.Controls.MaterialRadioButton dictionary_radioBtn;
        private System.Windows.Forms.TabPage tabPage3;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBox_hashidnty;
        private MaterialSkin.Controls.MaterialRaisedButton identifier_btn_identify;
        private MaterialSkin.Controls.MaterialLabel lbl_identify;
        private MaterialSkin.Controls.MaterialLabel materialLabel13;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialRaisedButton decrypt_btn_stop;
        private System.Windows.Forms.PictureBox pictureBoxBlack3;
        private System.Windows.Forms.PictureBox pictureBoxWhite3;
        private MaterialSkin.Controls.MaterialRaisedButton identifier_btn_reset;
        private MaterialSkin.Controls.MaterialLabel materialLabel17;
        private MaterialSkin.Controls.MaterialLabel decrypt_lbl_time;
        private System.Windows.Forms.Timer timer1;
        public MaterialSkin.Controls.MaterialLabel decrypt_lbl_progress;
        public MaterialSkin.Controls.MaterialLabel decrypt_lbl_counted;
        private MaterialSkin.Controls.MaterialRadioButton bruteforce_radioBtn;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private MaterialSkin.Controls.MaterialLabel materialLabel14;
        private MaterialSkin.Controls.MaterialLabel materialLabel12;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel9;
        private MaterialSkin.Controls.MaterialLabel materialLabel16;
        private MaterialSkin.Controls.MaterialLabel materialLabel15;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.ComponentModel.BackgroundWorker BGWorker2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private MaterialSkin.Controls.MaterialRadioButton base64_hashlist;
        private MaterialSkin.Controls.MaterialLabel materialLabel18;
        private MaterialSkin.Controls.MaterialRadioButton sha384_hashlist;
        private MaterialSkin.Controls.MaterialRaisedButton lstgen_btn_browse;
        private MaterialSkin.Controls.MaterialRadioButton sha1_hashlist;
        private MaterialSkin.Controls.MaterialRadioButton sha512_hashlist;
        private MaterialSkin.Controls.MaterialRadioButton md5_hashlist;
        private MaterialSkin.Controls.MaterialLabel materialLabel20;
        private MaterialSkin.Controls.MaterialRadioButton md5Reverse_hashlist;
        private MaterialSkin.Controls.MaterialRadioButton sha256_hashlist;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private MaterialSkin.Controls.MaterialRaisedButton lstgen_btn_gnrt;
        private MaterialSkin.Controls.MaterialRaisedButton lstgen_btn_reset;
        private MaterialSkin.Controls.MaterialLabel materialLabel22;
        private MaterialSkin.Controls.MaterialLabel lstgen_lbl_path;
        private MaterialSkin.Controls.MaterialLabel materialLabel25;
        private MaterialSkin.Controls.MaterialLabel lstgen_lbl_time;
        public MaterialSkin.Controls.MaterialLabel lstgen_lbl_counted;
        private MaterialSkin.Controls.MaterialLabel materialLabel32;
        private MaterialSkin.Controls.MaterialLabel materialLabel33;
        public MaterialSkin.Controls.MaterialLabel lstgen_lbl_progress;
        private MaterialSkin.Controls.MaterialLabel lstgen_lbl_status;
        private MaterialSkin.Controls.MaterialLabel materialLabel36;
        private MaterialSkin.Controls.MaterialCheckBox hashlist_autosave;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private MaterialSkin.Controls.MaterialLabel passgen_lbl_time;
        private MaterialSkin.Controls.MaterialLabel materialLabel27;
        private MaterialSkin.Controls.MaterialLabel materialLabel28;
        public MaterialSkin.Controls.MaterialLabel passgen_lbl_progress;
        private MaterialSkin.Controls.MaterialLabel passgen_lbl_status;
        private MaterialSkin.Controls.MaterialLabel materialLabel31;
        private System.Windows.Forms.GroupBox groupBox4;
        private MaterialSkin.Controls.MaterialRaisedButton passgen_btn_gnrt;
        private MaterialSkin.Controls.MaterialRaisedButton passgen_btn_reset;
        private System.Windows.Forms.GroupBox groupBox5;
        private MaterialSkin.Controls.MaterialCheckBox passlist_autosave;
        private MaterialSkin.Controls.MaterialRadioButton custom_passphrase_passlist;
        private MaterialSkin.Controls.MaterialRadioButton numeric_passlist;
        private MaterialSkin.Controls.MaterialRadioButton alphabet_az_passlist;
        private MaterialSkin.Controls.MaterialLabel materialLabel35;
        private MaterialSkin.Controls.MaterialRadioButton alphabet_az_capital_passlist;
        private MaterialSkin.Controls.MaterialRadioButton passphrase_passlist;
        private MaterialSkin.Controls.MaterialLabel lbl_chars;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBox_chars_passlist;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBox_len_passlist;
        private MaterialSkin.Controls.MaterialLabel materialLabel24;
        private System.ComponentModel.BackgroundWorker BGWorker3;
        private System.Windows.Forms.Timer timer3;
        private MaterialSkin.Controls.MaterialLabel materialLabel19;
        public MaterialSkin.Controls.MaterialLabel passgen_lbl_total;
    }
}

