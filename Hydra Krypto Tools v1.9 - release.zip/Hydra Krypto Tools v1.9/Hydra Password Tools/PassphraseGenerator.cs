﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hydra_Password_Tools
{
    class PassphraseGenerator
    {
        #region Resources
        public enum PassphraseType
        {
            Normal, Custom
        }

        /*
         * We can also write default constractor. Because we have only passphrase that is Not Static and we have to create instance
         * from class And because of this reason, we can only write default constructor.
         */

        public char[] charlist = {
                                    '0','1','2','3','4','5','6','7','8','9',
                                    'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','r','u','v','w','x','y','z',
                                    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','R','U','V','W','X','Y','Z',
                                    '!','@','#','$','%','&','*','^','(',')','_','-','+','=','`',
                                    ' ',',','.','\'','/','?','\\',';',':','"','<','>','[',']','{','}'
                                  };

        public char[] custom_charlist;


        public List<string> stringlist = new List<string>();

        #endregion

        #region Constructors
        public PassphraseGenerator() {} // Default constructor
        public PassphraseGenerator(PassphraseType type) // Normal
        {
            for (int i = 0; i < charlist.Length; i++)
            {
                stringlist.Add(charlist[i].ToString()); // Filling the stringlist
            }
        }

        public PassphraseGenerator(char[] chars, PassphraseType type = PassphraseType.Custom) // Custom
        {
            custom_charlist = chars;
            for (int i = 0; i < custom_charlist.Length; i++)
            {
                stringlist.Add(custom_charlist[i].ToString()); // Filling the stringlist
            }
        }

        #endregion

        #region Functions

        /// <summary>
        /// Generates all the strings that may be possible with alphabet a-z
        /// </summary>
        /// <param name="column">Position of string in alphabet</param>
        /// <returns>Returns the string that matches the desired position in the alphabet</returns>
        public static String passwdGenerator_az(decimal column)
        {
            column--;
            String col = Convert.ToString((char)('a' + (column % 26)));
            while (column >= 26)
            {
                column = (column / 26) - 1;
                col = Convert.ToString((char)('a' + (column % 26))) + col;
            }
            return col;
        }


        /// <summary>
        /// Generates all the strings that may be possible with alphabet A-Z
        /// </summary>
        /// <param name="column">Position of string in alphabet</param>
        /// <returns>Returns the string that matches the desired position in the alphabet</returns>
        public static String passwdGenerator_AZ(decimal column)
        {
            column--;
            String col = Convert.ToString((char)('A' + (column % 26)));
            while (column >= 26)
            {
                column = (column / 26) - 1;
                col = Convert.ToString((char)('A' + (column % 26))) + col;
            }
            return col;
        }


        /// <summary>
        /// Generates all the strings that may be possible 
        /// </summary>
        /// <param name="position">Position of string in charlist</param>
        /// <param name="string_list">The string list from which the password is to be generated</param>
        /// <returns>Returns the string that matches the desired position in the char array</returns>
        public string passphraseGenerator(int position, List<string> string_list)
        {
            List<int> mod_list = new List<int>();
            string output = "";

            while (position >= 0)
            {
                mod_list.Add(position % string_list.Count);
                position -= position % string_list.Count;
                position /= string_list.Count;
                position -= 1;
            }
            for (int i = (mod_list.Count - 1); i >= 0; i += -1)
                output += string_list[mod_list[i]];

            return output;
        }

        #endregion
    }
}
