﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hydra_Password_Tools
{
    class PasswordGenerator
    {
        //Alphabetical a-z Password Generator
        public static String passwdGenerator_az(decimal column)
        {
            column--;
            String col = Convert.ToString((char)('a' + (column % 26)));
            while (column >= 26)
            {
                column = (column / 26) - 1;
                col = Convert.ToString((char)('a' + (column % 26))) + col;
            }
            return col;
        }

        //Alphabetical A-Z Password Generator
        public static String passwdGenerator_AZ(decimal column)
        {
            column--;
            String col = Convert.ToString((char)('A' + (column % 26)));
            while (column >= 26)
            {
                column = (column / 26) - 1;
                col = Convert.ToString((char)('A' + (column % 26))) + col;
            }
            return col;
        }
    }
}
