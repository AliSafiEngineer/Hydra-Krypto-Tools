﻿namespace Hydra_Password_Tools
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.materialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.base64_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.md5_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha384_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha512_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha256_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha1_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.pictureBoxBlack = new System.Windows.Forms.PictureBox();
            this.pictureBoxWhite = new System.Windows.Forms.PictureBox();
            this.materialRaisedButton2 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.txtBoxResult = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.inputRaw = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.md5Reverse_Encrypt = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbl_time = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel17 = new MaterialSkin.Controls.MaterialLabel();
            this.btn_stop = new MaterialSkin.Controls.MaterialRaisedButton();
            this.lbl_progress = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.lbl_status = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel10 = new MaterialSkin.Controls.MaterialLabel();
            this.materialRaisedButton4 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bruteforce_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.alphabetical_azCapital_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.alphabetical_az_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.numerical_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.dictionary_radioBtn = new MaterialSkin.Controls.MaterialRadioButton();
            this.pictureBoxWhite2 = new System.Windows.Forms.PictureBox();
            this.sha256_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha384_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.base64_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha512_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.md5Reverse_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.sha1_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.lbl_counted = new MaterialSkin.Controls.MaterialLabel();
            this.lbl_count = new MaterialSkin.Controls.MaterialLabel();
            this.materialRaisedButton6 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton5 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.outputBox = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel11 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel8 = new MaterialSkin.Controls.MaterialLabel();
            this.browse_btn = new MaterialSkin.Controls.MaterialRaisedButton();
            this.lbl_list = new MaterialSkin.Controls.MaterialLabel();
            this.path_label = new MaterialSkin.Controls.MaterialLabel();
            this.md5_algorithm = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel7 = new MaterialSkin.Controls.MaterialLabel();
            this.inputHash = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.pictureBoxBlack2 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.reset_btn = new MaterialSkin.Controls.MaterialRaisedButton();
            this.pictureBoxBlack3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxWhite3 = new System.Windows.Forms.PictureBox();
            this.lbl_identify = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel13 = new MaterialSkin.Controls.MaterialLabel();
            this.Identify_Btn = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txtBox_hashidnty = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.materialLabel14 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel12 = new MaterialSkin.Controls.MaterialLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.materialLabel9 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel16 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel15 = new MaterialSkin.Controls.MaterialLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.BGWorker = new System.ComponentModel.BackgroundWorker();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialFlatButton1
            // 
            this.materialFlatButton1.AutoSize = true;
            this.materialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.materialFlatButton1.Depth = 0;
            this.materialFlatButton1.Location = new System.Drawing.Point(669, 68);
            this.materialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.materialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialFlatButton1.Name = "materialFlatButton1";
            this.materialFlatButton1.Primary = false;
            this.materialFlatButton1.Size = new System.Drawing.Size(116, 36);
            this.materialFlatButton1.TabIndex = 6;
            this.materialFlatButton1.Text = "Change Theme";
            this.materialFlatButton1.UseVisualStyleBackColor = true;
            this.materialFlatButton1.Click += new System.EventHandler(this.materialFlatButton1_Click);
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.BaseTabControl = this.materialTabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(-10, 108);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(796, 32);
            this.materialTabSelector1.TabIndex = 27;
            this.materialTabSelector1.Text = "materialTabSelector1";
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Controls.Add(this.tabPage4);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Location = new System.Drawing.Point(12, 143);
            this.materialTabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(773, 623);
            this.materialTabControl1.TabIndex = 29;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.base64_Encrypt);
            this.tabPage1.Controls.Add(this.md5_Encrypt);
            this.tabPage1.Controls.Add(this.sha384_Encrypt);
            this.tabPage1.Controls.Add(this.sha512_Encrypt);
            this.tabPage1.Controls.Add(this.sha256_Encrypt);
            this.tabPage1.Controls.Add(this.sha1_Encrypt);
            this.tabPage1.Controls.Add(this.pictureBoxBlack);
            this.tabPage1.Controls.Add(this.pictureBoxWhite);
            this.tabPage1.Controls.Add(this.materialRaisedButton2);
            this.tabPage1.Controls.Add(this.materialLabel4);
            this.tabPage1.Controls.Add(this.txtBoxResult);
            this.tabPage1.Controls.Add(this.materialRaisedButton1);
            this.tabPage1.Controls.Add(this.inputRaw);
            this.tabPage1.Controls.Add(this.materialLabel1);
            this.tabPage1.Controls.Add(this.md5Reverse_Encrypt);
            this.tabPage1.Controls.Add(this.materialLabel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(765, 597);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ENCRYPTION";
            // 
            // base64_Encrypt
            // 
            this.base64_Encrypt.AutoSize = true;
            this.base64_Encrypt.Depth = 0;
            this.base64_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.base64_Encrypt.Location = new System.Drawing.Point(359, 98);
            this.base64_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.base64_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.base64_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.base64_Encrypt.Name = "base64_Encrypt";
            this.base64_Encrypt.Ripple = true;
            this.base64_Encrypt.Size = new System.Drawing.Size(75, 30);
            this.base64_Encrypt.TabIndex = 33;
            this.base64_Encrypt.TabStop = true;
            this.base64_Encrypt.Text = "Base64";
            this.base64_Encrypt.UseVisualStyleBackColor = true;
            // 
            // md5_Encrypt
            // 
            this.md5_Encrypt.AutoSize = true;
            this.md5_Encrypt.Depth = 0;
            this.md5_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5_Encrypt.Location = new System.Drawing.Point(16, 98);
            this.md5_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.md5_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5_Encrypt.Name = "md5_Encrypt";
            this.md5_Encrypt.Ripple = true;
            this.md5_Encrypt.Size = new System.Drawing.Size(58, 30);
            this.md5_Encrypt.TabIndex = 13;
            this.md5_Encrypt.Text = "MD5";
            this.md5_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha384_Encrypt
            // 
            this.sha384_Encrypt.AutoSize = true;
            this.sha384_Encrypt.Depth = 0;
            this.sha384_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha384_Encrypt.Location = new System.Drawing.Point(119, 128);
            this.sha384_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha384_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha384_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha384_Encrypt.Name = "sha384_Encrypt";
            this.sha384_Encrypt.Ripple = true;
            this.sha384_Encrypt.Size = new System.Drawing.Size(84, 30);
            this.sha384_Encrypt.TabIndex = 17;
            this.sha384_Encrypt.Text = "SHA-384";
            this.sha384_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha512_Encrypt
            // 
            this.sha512_Encrypt.AutoSize = true;
            this.sha512_Encrypt.Depth = 0;
            this.sha512_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha512_Encrypt.Location = new System.Drawing.Point(244, 128);
            this.sha512_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha512_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha512_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha512_Encrypt.Name = "sha512_Encrypt";
            this.sha512_Encrypt.Ripple = true;
            this.sha512_Encrypt.Size = new System.Drawing.Size(84, 30);
            this.sha512_Encrypt.TabIndex = 19;
            this.sha512_Encrypt.Text = "SHA-512";
            this.sha512_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha256_Encrypt
            // 
            this.sha256_Encrypt.AutoSize = true;
            this.sha256_Encrypt.Depth = 0;
            this.sha256_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha256_Encrypt.Location = new System.Drawing.Point(16, 128);
            this.sha256_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha256_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha256_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha256_Encrypt.Name = "sha256_Encrypt";
            this.sha256_Encrypt.Ripple = true;
            this.sha256_Encrypt.Size = new System.Drawing.Size(84, 30);
            this.sha256_Encrypt.TabIndex = 16;
            this.sha256_Encrypt.Text = "SHA-256";
            this.sha256_Encrypt.UseVisualStyleBackColor = true;
            // 
            // sha1_Encrypt
            // 
            this.sha1_Encrypt.AutoSize = true;
            this.sha1_Encrypt.Depth = 0;
            this.sha1_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha1_Encrypt.Location = new System.Drawing.Point(244, 98);
            this.sha1_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.sha1_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha1_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha1_Encrypt.Name = "sha1_Encrypt";
            this.sha1_Encrypt.Ripple = true;
            this.sha1_Encrypt.Size = new System.Drawing.Size(68, 30);
            this.sha1_Encrypt.TabIndex = 18;
            this.sha1_Encrypt.Text = "SHA-1";
            this.sha1_Encrypt.UseVisualStyleBackColor = true;
            // 
            // pictureBoxBlack
            // 
            this.pictureBoxBlack.Image = global::Hydra_Password_Tools.Properties.Resources.in_app;
            this.pictureBoxBlack.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxBlack.Name = "pictureBoxBlack";
            this.pictureBoxBlack.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxBlack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxBlack.TabIndex = 26;
            this.pictureBoxBlack.TabStop = false;
            // 
            // pictureBoxWhite
            // 
            this.pictureBoxWhite.Image = global::Hydra_Password_Tools.Properties.Resources.in_app_white1;
            this.pictureBoxWhite.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxWhite.Name = "pictureBoxWhite";
            this.pictureBoxWhite.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxWhite.TabIndex = 25;
            this.pictureBoxWhite.TabStop = false;
            // 
            // materialRaisedButton2
            // 
            this.materialRaisedButton2.Depth = 0;
            this.materialRaisedButton2.Location = new System.Drawing.Point(475, 575);
            this.materialRaisedButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton2.Name = "materialRaisedButton2";
            this.materialRaisedButton2.Primary = true;
            this.materialRaisedButton2.Size = new System.Drawing.Size(83, 29);
            this.materialRaisedButton2.TabIndex = 24;
            this.materialRaisedButton2.Text = "COPY";
            this.materialRaisedButton2.UseVisualStyleBackColor = true;
            this.materialRaisedButton2.Click += new System.EventHandler(this.materialRaisedButton2_Click);
            // 
            // materialLabel4
            // 
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(140, 582);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(51, 18);
            this.materialLabel4.TabIndex = 23;
            this.materialLabel4.Text = "Hash :";
            // 
            // txtBoxResult
            // 
            this.txtBoxResult.Depth = 0;
            this.txtBoxResult.Hint = "";
            this.txtBoxResult.Location = new System.Drawing.Point(199, 578);
            this.txtBoxResult.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBoxResult.Name = "txtBoxResult";
            this.txtBoxResult.PasswordChar = '\0';
            this.txtBoxResult.SelectedText = "";
            this.txtBoxResult.SelectionLength = 0;
            this.txtBoxResult.SelectionStart = 0;
            this.txtBoxResult.Size = new System.Drawing.Size(246, 23);
            this.txtBoxResult.TabIndex = 22;
            this.txtBoxResult.UseSystemPasswordChar = false;
            this.txtBoxResult.TextChanged += new System.EventHandler(this.txtBoxResult_TextChanged);
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(13, 565);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(111, 39);
            this.materialRaisedButton1.TabIndex = 21;
            this.materialRaisedButton1.Text = "Start Hash";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // inputRaw
            // 
            this.inputRaw.Depth = 0;
            this.inputRaw.Hint = "";
            this.inputRaw.Location = new System.Drawing.Point(188, 18);
            this.inputRaw.MouseState = MaterialSkin.MouseState.HOVER;
            this.inputRaw.Name = "inputRaw";
            this.inputRaw.PasswordChar = '\0';
            this.inputRaw.SelectedText = "";
            this.inputRaw.SelectionLength = 0;
            this.inputRaw.SelectionStart = 0;
            this.inputRaw.Size = new System.Drawing.Size(352, 23);
            this.inputRaw.TabIndex = 9;
            this.inputRaw.UseSystemPasswordChar = false;
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(16, 23);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(166, 18);
            this.materialLabel1.TabIndex = 8;
            this.materialLabel1.Text = "Enter your Passphrase :";
            // 
            // md5Reverse_Encrypt
            // 
            this.md5Reverse_Encrypt.AutoSize = true;
            this.md5Reverse_Encrypt.Depth = 0;
            this.md5Reverse_Encrypt.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5Reverse_Encrypt.Location = new System.Drawing.Point(119, 98);
            this.md5Reverse_Encrypt.Margin = new System.Windows.Forms.Padding(0);
            this.md5Reverse_Encrypt.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5Reverse_Encrypt.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5Reverse_Encrypt.Name = "md5Reverse_Encrypt";
            this.md5Reverse_Encrypt.Ripple = true;
            this.md5Reverse_Encrypt.Size = new System.Drawing.Size(111, 30);
            this.md5Reverse_Encrypt.TabIndex = 15;
            this.md5Reverse_Encrypt.Text = "MD5 Reverse";
            this.md5Reverse_Encrypt.UseVisualStyleBackColor = true;
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(16, 66);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(174, 18);
            this.materialLabel2.TabIndex = 14;
            this.materialLabel2.Text = "Choose encryption type :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.lbl_time);
            this.tabPage2.Controls.Add(this.materialLabel17);
            this.tabPage2.Controls.Add(this.btn_stop);
            this.tabPage2.Controls.Add(this.lbl_progress);
            this.tabPage2.Controls.Add(this.materialLabel5);
            this.tabPage2.Controls.Add(this.lbl_status);
            this.tabPage2.Controls.Add(this.materialLabel10);
            this.tabPage2.Controls.Add(this.materialRaisedButton4);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.pictureBoxWhite2);
            this.tabPage2.Controls.Add(this.sha256_algorithm);
            this.tabPage2.Controls.Add(this.sha384_algorithm);
            this.tabPage2.Controls.Add(this.base64_algorithm);
            this.tabPage2.Controls.Add(this.sha512_algorithm);
            this.tabPage2.Controls.Add(this.md5Reverse_algorithm);
            this.tabPage2.Controls.Add(this.sha1_algorithm);
            this.tabPage2.Controls.Add(this.lbl_counted);
            this.tabPage2.Controls.Add(this.lbl_count);
            this.tabPage2.Controls.Add(this.materialRaisedButton6);
            this.tabPage2.Controls.Add(this.materialRaisedButton5);
            this.tabPage2.Controls.Add(this.outputBox);
            this.tabPage2.Controls.Add(this.materialLabel11);
            this.tabPage2.Controls.Add(this.materialLabel8);
            this.tabPage2.Controls.Add(this.browse_btn);
            this.tabPage2.Controls.Add(this.lbl_list);
            this.tabPage2.Controls.Add(this.path_label);
            this.tabPage2.Controls.Add(this.md5_algorithm);
            this.tabPage2.Controls.Add(this.materialLabel7);
            this.tabPage2.Controls.Add(this.inputHash);
            this.tabPage2.Controls.Add(this.materialLabel6);
            this.tabPage2.Controls.Add(this.pictureBoxBlack2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(765, 597);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "DECRYPTION";
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.Depth = 0;
            this.lbl_time.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_time.Location = new System.Drawing.Point(114, 519);
            this.lbl_time.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(64, 18);
            this.lbl_time.TabIndex = 51;
            this.lbl_time.Text = "00:00:00";
            // 
            // materialLabel17
            // 
            this.materialLabel17.AutoSize = true;
            this.materialLabel17.Depth = 0;
            this.materialLabel17.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel17.Location = new System.Drawing.Point(8, 519);
            this.materialLabel17.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel17.Name = "materialLabel17";
            this.materialLabel17.Size = new System.Drawing.Size(103, 18);
            this.materialLabel17.TabIndex = 50;
            this.materialLabel17.Text = "Elapsed time :";
            // 
            // btn_stop
            // 
            this.btn_stop.Depth = 0;
            this.btn_stop.Location = new System.Drawing.Point(134, 439);
            this.btn_stop.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Primary = true;
            this.btn_stop.Size = new System.Drawing.Size(76, 36);
            this.btn_stop.TabIndex = 49;
            this.btn_stop.Text = "Cancel";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.materialRaisedButton3_Click_1);
            // 
            // lbl_progress
            // 
            this.lbl_progress.AutoSize = true;
            this.lbl_progress.Depth = 0;
            this.lbl_progress.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_progress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_progress.Location = new System.Drawing.Point(88, 549);
            this.lbl_progress.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_progress.Name = "lbl_progress";
            this.lbl_progress.Size = new System.Drawing.Size(31, 18);
            this.lbl_progress.TabIndex = 48;
            this.lbl_progress.Text = "0 %";
            // 
            // materialLabel5
            // 
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel5.Location = new System.Drawing.Point(8, 549);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(76, 18);
            this.materialLabel5.TabIndex = 47;
            this.materialLabel5.Text = "Progress :";
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Depth = 0;
            this.lbl_status.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_status.Location = new System.Drawing.Point(70, 491);
            this.lbl_status.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(52, 18);
            this.lbl_status.TabIndex = 37;
            this.lbl_status.Text = "None !";
            // 
            // materialLabel10
            // 
            this.materialLabel10.AutoSize = true;
            this.materialLabel10.Depth = 0;
            this.materialLabel10.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel10.Location = new System.Drawing.Point(8, 491);
            this.materialLabel10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel10.Name = "materialLabel10";
            this.materialLabel10.Size = new System.Drawing.Size(59, 18);
            this.materialLabel10.TabIndex = 36;
            this.materialLabel10.Text = "Status :";
            // 
            // materialRaisedButton4
            // 
            this.materialRaisedButton4.Depth = 0;
            this.materialRaisedButton4.Location = new System.Drawing.Point(10, 439);
            this.materialRaisedButton4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton4.Name = "materialRaisedButton4";
            this.materialRaisedButton4.Primary = true;
            this.materialRaisedButton4.Size = new System.Drawing.Size(108, 36);
            this.materialRaisedButton4.TabIndex = 38;
            this.materialRaisedButton4.Text = "Start Crack";
            this.materialRaisedButton4.UseVisualStyleBackColor = true;
            this.materialRaisedButton4.Click += new System.EventHandler(this.materialRaisedButton4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox2.Controls.Add(this.bruteforce_radioBtn);
            this.groupBox2.Controls.Add(this.alphabetical_azCapital_radioBtn);
            this.groupBox2.Controls.Add(this.alphabetical_az_radioBtn);
            this.groupBox2.Controls.Add(this.numerical_radioBtn);
            this.groupBox2.Controls.Add(this.dictionary_radioBtn);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(10, 193);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(488, 95);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Crack Method";
            // 
            // bruteforce_radioBtn
            // 
            this.bruteforce_radioBtn.AutoSize = true;
            this.bruteforce_radioBtn.Depth = 0;
            this.bruteforce_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.bruteforce_radioBtn.Location = new System.Drawing.Point(6, 52);
            this.bruteforce_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.bruteforce_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.bruteforce_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.bruteforce_radioBtn.Name = "bruteforce_radioBtn";
            this.bruteforce_radioBtn.Ripple = true;
            this.bruteforce_radioBtn.Size = new System.Drawing.Size(97, 30);
            this.bruteforce_radioBtn.TabIndex = 8;
            this.bruteforce_radioBtn.TabStop = true;
            this.bruteforce_radioBtn.Text = "BruteForce";
            this.bruteforce_radioBtn.UseVisualStyleBackColor = true;
            // 
            // alphabetical_azCapital_radioBtn
            // 
            this.alphabetical_azCapital_radioBtn.AutoSize = true;
            this.alphabetical_azCapital_radioBtn.Depth = 0;
            this.alphabetical_azCapital_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.alphabetical_azCapital_radioBtn.Location = new System.Drawing.Point(314, 19);
            this.alphabetical_azCapital_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.alphabetical_azCapital_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.alphabetical_azCapital_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.alphabetical_azCapital_radioBtn.Name = "alphabetical_azCapital_radioBtn";
            this.alphabetical_azCapital_radioBtn.Ripple = true;
            this.alphabetical_azCapital_radioBtn.Size = new System.Drawing.Size(131, 30);
            this.alphabetical_azCapital_radioBtn.TabIndex = 7;
            this.alphabetical_azCapital_radioBtn.TabStop = true;
            this.alphabetical_azCapital_radioBtn.Text = "Alphabetical A-Z";
            this.alphabetical_azCapital_radioBtn.UseVisualStyleBackColor = true;
            // 
            // alphabetical_az_radioBtn
            // 
            this.alphabetical_az_radioBtn.AutoSize = true;
            this.alphabetical_az_radioBtn.Depth = 0;
            this.alphabetical_az_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.alphabetical_az_radioBtn.Location = new System.Drawing.Point(164, 19);
            this.alphabetical_az_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.alphabetical_az_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.alphabetical_az_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.alphabetical_az_radioBtn.Name = "alphabetical_az_radioBtn";
            this.alphabetical_az_radioBtn.Ripple = true;
            this.alphabetical_az_radioBtn.Size = new System.Drawing.Size(131, 30);
            this.alphabetical_az_radioBtn.TabIndex = 6;
            this.alphabetical_az_radioBtn.TabStop = true;
            this.alphabetical_az_radioBtn.Text = "Alphabetical  a-z";
            this.alphabetical_az_radioBtn.UseVisualStyleBackColor = true;
            // 
            // numerical_radioBtn
            // 
            this.numerical_radioBtn.AutoSize = true;
            this.numerical_radioBtn.Depth = 0;
            this.numerical_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.numerical_radioBtn.Location = new System.Drawing.Point(164, 52);
            this.numerical_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.numerical_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.numerical_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.numerical_radioBtn.Name = "numerical_radioBtn";
            this.numerical_radioBtn.Ripple = true;
            this.numerical_radioBtn.Size = new System.Drawing.Size(92, 30);
            this.numerical_radioBtn.TabIndex = 5;
            this.numerical_radioBtn.TabStop = true;
            this.numerical_radioBtn.Text = "Numerical";
            this.numerical_radioBtn.UseVisualStyleBackColor = true;
            // 
            // dictionary_radioBtn
            // 
            this.dictionary_radioBtn.AutoSize = true;
            this.dictionary_radioBtn.Depth = 0;
            this.dictionary_radioBtn.Font = new System.Drawing.Font("Roboto", 10F);
            this.dictionary_radioBtn.Location = new System.Drawing.Point(6, 19);
            this.dictionary_radioBtn.Margin = new System.Windows.Forms.Padding(0);
            this.dictionary_radioBtn.MouseLocation = new System.Drawing.Point(-1, -1);
            this.dictionary_radioBtn.MouseState = MaterialSkin.MouseState.HOVER;
            this.dictionary_radioBtn.Name = "dictionary_radioBtn";
            this.dictionary_radioBtn.Ripple = true;
            this.dictionary_radioBtn.Size = new System.Drawing.Size(133, 30);
            this.dictionary_radioBtn.TabIndex = 4;
            this.dictionary_radioBtn.TabStop = true;
            this.dictionary_radioBtn.Text = "Dictionary attack";
            this.dictionary_radioBtn.UseVisualStyleBackColor = true;
            // 
            // pictureBoxWhite2
            // 
            this.pictureBoxWhite2.Image = global::Hydra_Password_Tools.Properties.Resources.in_app_white1;
            this.pictureBoxWhite2.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxWhite2.Name = "pictureBoxWhite2";
            this.pictureBoxWhite2.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxWhite2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxWhite2.TabIndex = 45;
            this.pictureBoxWhite2.TabStop = false;
            // 
            // sha256_algorithm
            // 
            this.sha256_algorithm.AutoSize = true;
            this.sha256_algorithm.Depth = 0;
            this.sha256_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha256_algorithm.Location = new System.Drawing.Point(10, 138);
            this.sha256_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha256_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha256_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha256_algorithm.Name = "sha256_algorithm";
            this.sha256_algorithm.Ripple = true;
            this.sha256_algorithm.Size = new System.Drawing.Size(84, 30);
            this.sha256_algorithm.TabIndex = 27;
            this.sha256_algorithm.TabStop = true;
            this.sha256_algorithm.Text = "SHA-256";
            this.sha256_algorithm.UseVisualStyleBackColor = true;
            // 
            // sha384_algorithm
            // 
            this.sha384_algorithm.AutoSize = true;
            this.sha384_algorithm.Depth = 0;
            this.sha384_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha384_algorithm.Location = new System.Drawing.Point(117, 138);
            this.sha384_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha384_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha384_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha384_algorithm.Name = "sha384_algorithm";
            this.sha384_algorithm.Ripple = true;
            this.sha384_algorithm.Size = new System.Drawing.Size(84, 30);
            this.sha384_algorithm.TabIndex = 29;
            this.sha384_algorithm.TabStop = true;
            this.sha384_algorithm.Text = "SHA-384";
            this.sha384_algorithm.UseVisualStyleBackColor = true;
            // 
            // base64_algorithm
            // 
            this.base64_algorithm.AutoSize = true;
            this.base64_algorithm.Depth = 0;
            this.base64_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.base64_algorithm.Location = new System.Drawing.Point(337, 108);
            this.base64_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.base64_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.base64_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.base64_algorithm.Name = "base64_algorithm";
            this.base64_algorithm.Ripple = true;
            this.base64_algorithm.Size = new System.Drawing.Size(75, 30);
            this.base64_algorithm.TabIndex = 31;
            this.base64_algorithm.TabStop = true;
            this.base64_algorithm.Text = "Base64";
            this.base64_algorithm.UseVisualStyleBackColor = true;
            this.base64_algorithm.CheckedChanged += new System.EventHandler(this.base64_algorithm_CheckedChanged);
            // 
            // sha512_algorithm
            // 
            this.sha512_algorithm.AutoSize = true;
            this.sha512_algorithm.Depth = 0;
            this.sha512_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha512_algorithm.Location = new System.Drawing.Point(237, 138);
            this.sha512_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha512_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha512_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha512_algorithm.Name = "sha512_algorithm";
            this.sha512_algorithm.Ripple = true;
            this.sha512_algorithm.Size = new System.Drawing.Size(84, 30);
            this.sha512_algorithm.TabIndex = 31;
            this.sha512_algorithm.TabStop = true;
            this.sha512_algorithm.Text = "SHA-512";
            this.sha512_algorithm.UseVisualStyleBackColor = true;
            // 
            // md5Reverse_algorithm
            // 
            this.md5Reverse_algorithm.AutoSize = true;
            this.md5Reverse_algorithm.Depth = 0;
            this.md5Reverse_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5Reverse_algorithm.Location = new System.Drawing.Point(117, 108);
            this.md5Reverse_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.md5Reverse_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5Reverse_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5Reverse_algorithm.Name = "md5Reverse_algorithm";
            this.md5Reverse_algorithm.Ripple = true;
            this.md5Reverse_algorithm.Size = new System.Drawing.Size(111, 30);
            this.md5Reverse_algorithm.TabIndex = 28;
            this.md5Reverse_algorithm.TabStop = true;
            this.md5Reverse_algorithm.Text = "MD5 Reverse";
            this.md5Reverse_algorithm.UseVisualStyleBackColor = true;
            // 
            // sha1_algorithm
            // 
            this.sha1_algorithm.AutoSize = true;
            this.sha1_algorithm.Depth = 0;
            this.sha1_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.sha1_algorithm.Location = new System.Drawing.Point(237, 108);
            this.sha1_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.sha1_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.sha1_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.sha1_algorithm.Name = "sha1_algorithm";
            this.sha1_algorithm.Ripple = true;
            this.sha1_algorithm.Size = new System.Drawing.Size(68, 30);
            this.sha1_algorithm.TabIndex = 30;
            this.sha1_algorithm.TabStop = true;
            this.sha1_algorithm.Text = "SHA-1";
            this.sha1_algorithm.UseVisualStyleBackColor = true;
            // 
            // lbl_counted
            // 
            this.lbl_counted.AutoSize = true;
            this.lbl_counted.Depth = 0;
            this.lbl_counted.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_counted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_counted.Location = new System.Drawing.Point(167, 393);
            this.lbl_counted.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_counted.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_counted.Name = "lbl_counted";
            this.lbl_counted.Size = new System.Drawing.Size(16, 18);
            this.lbl_counted.TabIndex = 44;
            this.lbl_counted.Text = "0";
            // 
            // lbl_count
            // 
            this.lbl_count.AutoSize = true;
            this.lbl_count.Depth = 0;
            this.lbl_count.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_count.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_count.Location = new System.Drawing.Point(13, 393);
            this.lbl_count.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_count.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_count.Name = "lbl_count";
            this.lbl_count.Size = new System.Drawing.Size(154, 18);
            this.lbl_count.TabIndex = 43;
            this.lbl_count.Text = "Loaded passphrases :";
            // 
            // materialRaisedButton6
            // 
            this.materialRaisedButton6.Depth = 0;
            this.materialRaisedButton6.Location = new System.Drawing.Point(486, 576);
            this.materialRaisedButton6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton6.Name = "materialRaisedButton6";
            this.materialRaisedButton6.Primary = true;
            this.materialRaisedButton6.Size = new System.Drawing.Size(74, 29);
            this.materialRaisedButton6.TabIndex = 42;
            this.materialRaisedButton6.Text = "Reset";
            this.materialRaisedButton6.UseVisualStyleBackColor = true;
            this.materialRaisedButton6.Click += new System.EventHandler(this.materialRaisedButton6_Click);
            // 
            // materialRaisedButton5
            // 
            this.materialRaisedButton5.Depth = 0;
            this.materialRaisedButton5.Location = new System.Drawing.Point(413, 576);
            this.materialRaisedButton5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton5.Name = "materialRaisedButton5";
            this.materialRaisedButton5.Primary = true;
            this.materialRaisedButton5.Size = new System.Drawing.Size(67, 29);
            this.materialRaisedButton5.TabIndex = 41;
            this.materialRaisedButton5.Text = "COPY";
            this.materialRaisedButton5.UseVisualStyleBackColor = true;
            this.materialRaisedButton5.Click += new System.EventHandler(this.materialRaisedButton5_Click);
            // 
            // outputBox
            // 
            this.outputBox.Depth = 0;
            this.outputBox.Hint = "";
            this.outputBox.Location = new System.Drawing.Point(108, 577);
            this.outputBox.MouseState = MaterialSkin.MouseState.HOVER;
            this.outputBox.Name = "outputBox";
            this.outputBox.PasswordChar = '\0';
            this.outputBox.SelectedText = "";
            this.outputBox.SelectionLength = 0;
            this.outputBox.SelectionStart = 0;
            this.outputBox.Size = new System.Drawing.Size(274, 23);
            this.outputBox.TabIndex = 40;
            this.outputBox.UseSystemPasswordChar = false;
            this.outputBox.TextChanged += new System.EventHandler(this.outputBox_TextChanged);
            // 
            // materialLabel11
            // 
            this.materialLabel11.AutoSize = true;
            this.materialLabel11.Depth = 0;
            this.materialLabel11.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel11.Location = new System.Drawing.Point(8, 581);
            this.materialLabel11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel11.Name = "materialLabel11";
            this.materialLabel11.Size = new System.Drawing.Size(94, 18);
            this.materialLabel11.TabIndex = 39;
            this.materialLabel11.Text = "Passphrase :";
            // 
            // materialLabel8
            // 
            this.materialLabel8.AutoSize = true;
            this.materialLabel8.Depth = 0;
            this.materialLabel8.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel8.Location = new System.Drawing.Point(13, 323);
            this.materialLabel8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel8.Name = "materialLabel8";
            this.materialLabel8.Size = new System.Drawing.Size(172, 18);
            this.materialLabel8.TabIndex = 32;
            this.materialLabel8.Text = "Browse passphrase list :";
            // 
            // browse_btn
            // 
            this.browse_btn.Depth = 0;
            this.browse_btn.Location = new System.Drawing.Point(190, 315);
            this.browse_btn.MouseState = MaterialSkin.MouseState.HOVER;
            this.browse_btn.Name = "browse_btn";
            this.browse_btn.Primary = true;
            this.browse_btn.Size = new System.Drawing.Size(83, 33);
            this.browse_btn.TabIndex = 33;
            this.browse_btn.Text = "Browse...";
            this.browse_btn.UseVisualStyleBackColor = true;
            this.browse_btn.Click += new System.EventHandler(this.materialRaisedButton3_Click);
            // 
            // lbl_list
            // 
            this.lbl_list.AutoSize = true;
            this.lbl_list.Depth = 0;
            this.lbl_list.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_list.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_list.Location = new System.Drawing.Point(13, 363);
            this.lbl_list.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_list.Name = "lbl_list";
            this.lbl_list.Size = new System.Drawing.Size(40, 18);
            this.lbl_list.TabIndex = 34;
            this.lbl_list.Text = "File :";
            // 
            // path_label
            // 
            this.path_label.AutoSize = true;
            this.path_label.Depth = 0;
            this.path_label.Font = new System.Drawing.Font("Roboto", 11F);
            this.path_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.path_label.Location = new System.Drawing.Point(52, 363);
            this.path_label.MouseState = MaterialSkin.MouseState.HOVER;
            this.path_label.Name = "path_label";
            this.path_label.Size = new System.Drawing.Size(52, 18);
            this.path_label.TabIndex = 35;
            this.path_label.Text = "None !";
            // 
            // md5_algorithm
            // 
            this.md5_algorithm.AutoSize = true;
            this.md5_algorithm.Depth = 0;
            this.md5_algorithm.Font = new System.Drawing.Font("Roboto", 10F);
            this.md5_algorithm.Location = new System.Drawing.Point(10, 108);
            this.md5_algorithm.Margin = new System.Windows.Forms.Padding(0);
            this.md5_algorithm.MouseLocation = new System.Drawing.Point(-1, -1);
            this.md5_algorithm.MouseState = MaterialSkin.MouseState.HOVER;
            this.md5_algorithm.Name = "md5_algorithm";
            this.md5_algorithm.Ripple = true;
            this.md5_algorithm.Size = new System.Drawing.Size(58, 30);
            this.md5_algorithm.TabIndex = 26;
            this.md5_algorithm.TabStop = true;
            this.md5_algorithm.Text = "MD5";
            this.md5_algorithm.UseVisualStyleBackColor = true;
            // 
            // materialLabel7
            // 
            this.materialLabel7.AutoSize = true;
            this.materialLabel7.Depth = 0;
            this.materialLabel7.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel7.Location = new System.Drawing.Point(5, 75);
            this.materialLabel7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel7.Name = "materialLabel7";
            this.materialLabel7.Size = new System.Drawing.Size(174, 18);
            this.materialLabel7.TabIndex = 25;
            this.materialLabel7.Text = "Choose decryption type :";
            // 
            // inputHash
            // 
            this.inputHash.Depth = 0;
            this.inputHash.Hint = "";
            this.inputHash.Location = new System.Drawing.Point(139, 23);
            this.inputHash.MouseState = MaterialSkin.MouseState.HOVER;
            this.inputHash.Name = "inputHash";
            this.inputHash.PasswordChar = '\0';
            this.inputHash.SelectedText = "";
            this.inputHash.SelectionLength = 0;
            this.inputHash.SelectionStart = 0;
            this.inputHash.Size = new System.Drawing.Size(359, 23);
            this.inputHash.TabIndex = 24;
            this.inputHash.UseSystemPasswordChar = false;
            // 
            // materialLabel6
            // 
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel6.Location = new System.Drawing.Point(5, 28);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(123, 18);
            this.materialLabel6.TabIndex = 23;
            this.materialLabel6.Text = "Enter your Hash :";
            // 
            // pictureBoxBlack2
            // 
            this.pictureBoxBlack2.Image = global::Hydra_Password_Tools.Properties.Resources.in_app;
            this.pictureBoxBlack2.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxBlack2.Name = "pictureBoxBlack2";
            this.pictureBoxBlack2.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxBlack2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxBlack2.TabIndex = 15;
            this.pictureBoxBlack2.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.reset_btn);
            this.tabPage3.Controls.Add(this.pictureBoxBlack3);
            this.tabPage3.Controls.Add(this.pictureBoxWhite3);
            this.tabPage3.Controls.Add(this.lbl_identify);
            this.tabPage3.Controls.Add(this.materialLabel13);
            this.tabPage3.Controls.Add(this.Identify_Btn);
            this.tabPage3.Controls.Add(this.txtBox_hashidnty);
            this.tabPage3.Controls.Add(this.materialLabel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(765, 597);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Hash Identifier";
            // 
            // reset_btn
            // 
            this.reset_btn.Depth = 0;
            this.reset_btn.Location = new System.Drawing.Point(653, 73);
            this.reset_btn.MouseState = MaterialSkin.MouseState.HOVER;
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Primary = true;
            this.reset_btn.Size = new System.Drawing.Size(98, 33);
            this.reset_btn.TabIndex = 29;
            this.reset_btn.Text = "Reset";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // pictureBoxBlack3
            // 
            this.pictureBoxBlack3.Image = global::Hydra_Password_Tools.Properties.Resources.in_app;
            this.pictureBoxBlack3.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxBlack3.Name = "pictureBoxBlack3";
            this.pictureBoxBlack3.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxBlack3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxBlack3.TabIndex = 28;
            this.pictureBoxBlack3.TabStop = false;
            // 
            // pictureBoxWhite3
            // 
            this.pictureBoxWhite3.Image = global::Hydra_Password_Tools.Properties.Resources.in_app_white1;
            this.pictureBoxWhite3.Location = new System.Drawing.Point(568, 422);
            this.pictureBoxWhite3.Name = "pictureBoxWhite3";
            this.pictureBoxWhite3.Size = new System.Drawing.Size(205, 170);
            this.pictureBoxWhite3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxWhite3.TabIndex = 27;
            this.pictureBoxWhite3.TabStop = false;
            // 
            // lbl_identify
            // 
            this.lbl_identify.AutoSize = true;
            this.lbl_identify.Depth = 0;
            this.lbl_identify.Font = new System.Drawing.Font("Roboto", 11F);
            this.lbl_identify.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_identify.Location = new System.Drawing.Point(134, 132);
            this.lbl_identify.MouseState = MaterialSkin.MouseState.HOVER;
            this.lbl_identify.Name = "lbl_identify";
            this.lbl_identify.Size = new System.Drawing.Size(35, 18);
            this.lbl_identify.TabIndex = 5;
            this.lbl_identify.Text = "N/A";
            // 
            // materialLabel13
            // 
            this.materialLabel13.AutoSize = true;
            this.materialLabel13.Depth = 0;
            this.materialLabel13.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel13.Location = new System.Drawing.Point(15, 132);
            this.materialLabel13.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel13.Name = "materialLabel13";
            this.materialLabel13.Size = new System.Drawing.Size(119, 18);
            this.materialLabel13.TabIndex = 4;
            this.materialLabel13.Text = "Hash maybe be :";
            // 
            // Identify_Btn
            // 
            this.Identify_Btn.Depth = 0;
            this.Identify_Btn.Location = new System.Drawing.Point(18, 73);
            this.Identify_Btn.MouseState = MaterialSkin.MouseState.HOVER;
            this.Identify_Btn.Name = "Identify_Btn";
            this.Identify_Btn.Primary = true;
            this.Identify_Btn.Size = new System.Drawing.Size(619, 33);
            this.Identify_Btn.TabIndex = 3;
            this.Identify_Btn.Text = "Identify Hash";
            this.Identify_Btn.UseVisualStyleBackColor = true;
            this.Identify_Btn.Click += new System.EventHandler(this.Identify_Btn_Click);
            // 
            // txtBox_hashidnty
            // 
            this.txtBox_hashidnty.Depth = 0;
            this.txtBox_hashidnty.Hint = "";
            this.txtBox_hashidnty.Location = new System.Drawing.Point(141, 25);
            this.txtBox_hashidnty.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtBox_hashidnty.Name = "txtBox_hashidnty";
            this.txtBox_hashidnty.PasswordChar = '\0';
            this.txtBox_hashidnty.SelectedText = "";
            this.txtBox_hashidnty.SelectionLength = 0;
            this.txtBox_hashidnty.SelectionStart = 0;
            this.txtBox_hashidnty.Size = new System.Drawing.Size(496, 23);
            this.txtBox_hashidnty.TabIndex = 2;
            this.txtBox_hashidnty.UseSystemPasswordChar = false;
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(11, 29);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(123, 18);
            this.materialLabel3.TabIndex = 1;
            this.materialLabel3.Text = "Enter your Hash :";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.materialLabel14);
            this.tabPage4.Controls.Add(this.materialLabel12);
            this.tabPage4.Controls.Add(this.linkLabel1);
            this.tabPage4.Controls.Add(this.materialLabel9);
            this.tabPage4.Controls.Add(this.materialLabel16);
            this.tabPage4.Controls.Add(this.materialLabel15);
            this.tabPage4.Controls.Add(this.linkLabel2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(765, 597);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "About";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // materialLabel14
            // 
            this.materialLabel14.AutoSize = true;
            this.materialLabel14.Depth = 0;
            this.materialLabel14.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel14.Location = new System.Drawing.Point(6, 208);
            this.materialLabel14.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel14.Name = "materialLabel14";
            this.materialLabel14.Size = new System.Drawing.Size(246, 18);
            this.materialLabel14.TabIndex = 63;
            this.materialLabel14.Text = "Email : Alisafi.Engineer@gmail.com";
            // 
            // materialLabel12
            // 
            this.materialLabel12.AutoSize = true;
            this.materialLabel12.Depth = 0;
            this.materialLabel12.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel12.Location = new System.Drawing.Point(5, 129);
            this.materialLabel12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel12.Name = "materialLabel12";
            this.materialLabel12.Size = new System.Drawing.Size(74, 18);
            this.materialLabel12.TabIndex = 62;
            this.materialLabel12.Text = "Telegram:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.linkLabel1.Location = new System.Drawing.Point(69, 165);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(220, 20);
            this.linkLabel1.TabIndex = 59;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://github.com/GuiltyAngel";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // materialLabel9
            // 
            this.materialLabel9.AutoSize = true;
            this.materialLabel9.Depth = 0;
            this.materialLabel9.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel9.Location = new System.Drawing.Point(6, 168);
            this.materialLabel9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel9.Name = "materialLabel9";
            this.materialLabel9.Size = new System.Drawing.Size(66, 18);
            this.materialLabel9.TabIndex = 58;
            this.materialLabel9.Text = "GitHub : ";
            // 
            // materialLabel16
            // 
            this.materialLabel16.AutoSize = true;
            this.materialLabel16.Depth = 0;
            this.materialLabel16.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel16.Location = new System.Drawing.Point(6, 94);
            this.materialLabel16.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel16.Name = "materialLabel16";
            this.materialLabel16.Size = new System.Drawing.Size(136, 18);
            this.materialLabel16.TabIndex = 56;
            this.materialLabel16.Text = "Powered by Ali Safi";
            // 
            // materialLabel15
            // 
            this.materialLabel15.AutoSize = true;
            this.materialLabel15.Depth = 0;
            this.materialLabel15.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel15.Location = new System.Drawing.Point(6, 24);
            this.materialLabel15.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel15.Name = "materialLabel15";
            this.materialLabel15.Size = new System.Drawing.Size(256, 54);
            this.materialLabel15.TabIndex = 55;
            this.materialLabel15.Text = "About :\r\n\r\nHydra Krypto Tools Copyright © 2019";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.linkLabel2.Location = new System.Drawing.Point(79, 127);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(80, 20);
            this.linkLabel2.TabIndex = 53;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "@AliDesu";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked_1);
            // 
            // BGWorker
            // 
            this.BGWorker.WorkerReportsProgress = true;
            this.BGWorker.WorkerSupportsCancellation = true;
            this.BGWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BGWorker_DoWork);
            this.BGWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.BGWorker_ProgressChanged);
            this.BGWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.BGWorker_RunWorkerCompleted);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 768);
            this.Controls.Add(this.materialTabControl1);
            this.Controls.Add(this.materialTabSelector1);
            this.Controls.Add(this.materialFlatButton1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Hydra Krypto Tools v1.5 - Powered by Ali Safi";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBlack3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWhite3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialFlatButton materialFlatButton1;
        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private MaterialSkin.Controls.MaterialRadioButton base64_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton md5_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha384_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha512_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha256_Encrypt;
        private MaterialSkin.Controls.MaterialRadioButton sha1_Encrypt;
        private System.Windows.Forms.PictureBox pictureBoxBlack;
        private System.Windows.Forms.PictureBox pictureBoxWhite;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton2;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBoxResult;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
        private MaterialSkin.Controls.MaterialSingleLineTextField inputRaw;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialRadioButton md5Reverse_Encrypt;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBoxWhite2;
        private MaterialSkin.Controls.MaterialRadioButton sha256_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton sha384_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton base64_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton sha512_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton md5Reverse_algorithm;
        private MaterialSkin.Controls.MaterialRadioButton sha1_algorithm;
        private MaterialSkin.Controls.MaterialLabel lbl_count;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton6;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton5;
        private MaterialSkin.Controls.MaterialSingleLineTextField outputBox;
        private MaterialSkin.Controls.MaterialLabel materialLabel11;
        private MaterialSkin.Controls.MaterialLabel materialLabel8;
        private MaterialSkin.Controls.MaterialRaisedButton browse_btn;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton4;
        private MaterialSkin.Controls.MaterialLabel lbl_list;
        private MaterialSkin.Controls.MaterialLabel materialLabel10;
        private MaterialSkin.Controls.MaterialLabel path_label;
        private MaterialSkin.Controls.MaterialLabel lbl_status;
        private MaterialSkin.Controls.MaterialRadioButton md5_algorithm;
        private MaterialSkin.Controls.MaterialLabel materialLabel7;
        private MaterialSkin.Controls.MaterialSingleLineTextField inputHash;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private System.Windows.Forms.PictureBox pictureBoxBlack2;
        private System.ComponentModel.BackgroundWorker BGWorker;
        private System.Windows.Forms.GroupBox groupBox2;
        private MaterialSkin.Controls.MaterialRadioButton alphabetical_azCapital_radioBtn;
        private MaterialSkin.Controls.MaterialRadioButton alphabetical_az_radioBtn;
        private MaterialSkin.Controls.MaterialRadioButton numerical_radioBtn;
        private MaterialSkin.Controls.MaterialRadioButton dictionary_radioBtn;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private MaterialSkin.Controls.MaterialLabel materialLabel16;
        private MaterialSkin.Controls.MaterialLabel materialLabel15;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtBox_hashidnty;
        private MaterialSkin.Controls.MaterialRaisedButton Identify_Btn;
        private MaterialSkin.Controls.MaterialLabel lbl_identify;
        private MaterialSkin.Controls.MaterialLabel materialLabel13;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialRaisedButton btn_stop;
        private System.Windows.Forms.PictureBox pictureBoxBlack3;
        private System.Windows.Forms.PictureBox pictureBoxWhite3;
        private MaterialSkin.Controls.MaterialLabel materialLabel9;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel12;
        private MaterialSkin.Controls.MaterialLabel materialLabel14;
        private MaterialSkin.Controls.MaterialRaisedButton reset_btn;
        private MaterialSkin.Controls.MaterialLabel materialLabel17;
        private MaterialSkin.Controls.MaterialLabel lbl_time;
        private System.Windows.Forms.Timer timer;
        public MaterialSkin.Controls.MaterialLabel lbl_progress;
        public MaterialSkin.Controls.MaterialLabel lbl_counted;
        private MaterialSkin.Controls.MaterialRadioButton bruteforce_radioBtn;
    }
}

