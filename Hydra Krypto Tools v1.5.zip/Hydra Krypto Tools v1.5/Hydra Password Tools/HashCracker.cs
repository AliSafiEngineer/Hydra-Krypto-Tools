﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Forms;
namespace Hydra_Password_Tools
{
    class HashCracker : Hashing
    {
        private string str, hash_type,hash, file;
        private string user_input, orginal_input, result;
        public static bool stop = false;
        double currentline = 1, percentage;
        static Main MainForm = Application.OpenForms.OfType<Main>().FirstOrDefault();

        // Parametric constructor
        public HashCracker(string type)
        {
            if (type.Equals("md5"))
                hash_type = "md5";
            else if (type.Equals("sha1"))
                hash_type = "sha1";
            else if (type.Equals("sha256"))
                hash_type = "sha256";
            else if (type.Equals("sha384"))
                hash_type = "sha384";
            else if (type.Equals("sha512"))
                hash_type = "sha512";  
        }

        // Default constructor
        public HashCracker()
        {
            hash_type = "md5";
        }

        public static void ChangePercentage(string percentage)
        {
            MainForm.lbl_progress.Invoke(new Action(() =>
            {
                percentage += " %";
                MainForm.lbl_progress.Text = percentage;
            }));
            
        }

        public string hashtype
        {
            set
            {
                hash_type = value;
            }
        }
        public string openfile
        {
            set
            {
                file = value;
            }
        }
        public string GetHash
        {
            get { return hash; }
            set { str = value; }

        }
        public string input
        {
            set
            {
                user_input = value;
            }
        }

        public void crack()
        {
            try
            {
                StreamReader tmp = new StreamReader(file);
                tmp.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading file !\nError: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                result = "Error reading file !";
            }
            

            StreamReader read = new StreamReader(file);            
            double len = Convert.ToDouble(MainForm.lbl_counted.Text);
            switch (this.hash_type)
            {
                case "md5":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                result = "Operation cancelled !";
                                break;
                            }
                                
                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;

                            hash = HashMD5(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.user_input == this.GetHash)
                            {
                                result = orginal_input;
                                break;
                            }
                            else
                            {
                                result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }
                case "sha1":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA1(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.user_input == this.GetHash)
                            {
                                result = orginal_input;
                                break;
                            }
                            else
                            {
                                result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }

                case "sha256":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA256(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.user_input == this.GetHash)
                            {
                                result = orginal_input;
                                break;
                            }
                            else
                            {
                                result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }

                case "sha384":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                result = "Operation cancelled !";
                                break;
                            }

                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA384(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.user_input == this.GetHash)
                            {
                                result = orginal_input;
                                break;
                            }
                            else
                            {
                                result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }

                case "sha512":
                    {
                        while (read.EndOfStream == false)
                        {
                            if (stop)
                            {
                                result = "Operation cancelled !";
                                break;
                            }
                            orginal_input = read.ReadLine();
                            this.GetHash = orginal_input;
                            hash = HashSHA512(str);
                            percentage = Double.Parse(((currentline / len) * 100).ToString("0.0"));
                            ChangePercentage(percentage.ToString());
                            if (this.user_input == this.GetHash)
                            {
                                result = orginal_input;
                                break;
                            }
                            else
                            {
                                result = "Passphrase not found !";
                            }
                            currentline++;
                        }
                        break;
                    }
            }
        }
        public string GetResult
        {
            get
            {
                return result;
            }
        }

        // Hash functions
        /* Inherited */

        /*public void md5()
        {
            HashAlgorithm algorithm = MD5.Create();
            byte[] s = algorithm.ComputeHash(Encoding.UTF8.GetBytes(str));
            hash = BitConverter.ToString(s).Replace("-", "");
        }*/

        // For compare with this hash function: this.user_input.ToLower() == this.GetHash.Replace("-", "").ToLower()

    }
}
