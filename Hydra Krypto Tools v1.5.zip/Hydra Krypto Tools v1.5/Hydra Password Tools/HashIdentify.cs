﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hydra_Password_Tools
{
    class HashIdentify
    {
        public string GetHashType(string hash)
        {
            string type;

            bool flag = hash.Length.Equals(32);
            if (flag)
            {
                type = "MD5 / MD5 Reverse";
            }
            else
            {
                flag = hash.Length.Equals(40);
                if (flag)
                {
                    type = "SHA-1 / MySQL5";
                }
                else
                {
                    flag = hash.Length.Equals(13);
                    if (flag)
                    {
                        type = "DES(Unix)";
                    }
                    else
                    {
                        flag = hash.Length.Equals(16);
                        if (flag)
                        {
                            type = "MySQL / DES(Oracle Hash)";
                        }
                        else
                        {
                            flag = (hash.Length.Equals(41) & hash.StartsWith("*"));
                            if (flag)
                            {
                                type = "MySQL5";
                            }
                            else
                            {
                                flag = hash.Length.Equals(64);
                                if (flag)
                                {
                                    type = "SHA-256";
                                }
                                else
                                {
                                    flag = hash.Length.Equals(96);
                                    if (flag)
                                    {
                                        type = "SHA-384";
                                    }
                                    else
                                    {
                                        flag = hash.Length.Equals(128);
                                        if (flag)
                                        {
                                            type = "SHA-512";
                                        }
                                        else
                                        {
                                            flag = (hash.StartsWith("$1$") & hash.Length.Equals(34));
                                            if (flag)
                                            {
                                                type = "MD5(Unix)";
                                            }
                                            else
                                            {
                                                flag = (hash.StartsWith("$apr1$") & hash.Length.Equals(37));
                                                if (flag)
                                                {
                                                    type = "MD5(APR)";
                                                }
                                                else
                                                {
                                                    flag = (hash.StartsWith("$H$") & hash.Length.Equals(34));
                                                    if (flag)
                                                    {
                                                        type = "MD5(phpBB3)";
                                                    }
                                                    else
                                                    {
                                                        flag = (hash.StartsWith("$P$") & hash.Length.Equals(34));
                                                        if (flag)
                                                        {
                                                            type = "MD5(Wordpress)";
                                                        }
                                                        else
                                                        {
                                                            flag = (hash.StartsWith("$5$") & hash.Length.Equals(39));
                                                            if (flag)
                                                            {
                                                                type = "SHA-256(Unix)";
                                                            }
                                                            else
                                                            {
                                                                flag = (hash.StartsWith("$6$") & hash.Length.Equals(39));
                                                                if (flag)
                                                                {
                                                                    type = "SHA-512(Unix)";
                                                                }
                                                                else
                                                                {
                                                                    flag = (hash.Length.Equals(24) & hash.EndsWith("=="));
                                                                    if (flag)
                                                                    {
                                                                        type = "MD5(Base-64)";
                                                                    }
                                                                    else
                                                                    {
                                                                        flag = (hash.Length.Equals(28) & hash.EndsWith("="));
                                                                        if (flag)
                                                                        {
                                                                            type = "SHA-1(Base-64)";
                                                                        }
                                                                        else
                                                                        {
                                                                            flag = (hash.Length.Equals(40) & hash.EndsWith("=="));
                                                                            if (flag)
                                                                            {
                                                                                type = "SHA-224(Base-64)";
                                                                            }
                                                                            else
                                                                            {
                                                                                flag = (hash.Length.Equals(88) & hash.EndsWith("=="));
                                                                                if (flag)
                                                                                {
                                                                                    type = "SHA-512(Base-64)";
                                                                                }
                                                                                else
                                                                                {
                                                                                    flag = (hash.Length.Equals(44) & hash.EndsWith("="));
                                                                                    if (flag)
                                                                                    {
                                                                                        type = "SHA-256(Base-64)";
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        type = "Invalid Input/ Unidentified";
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return type;
        }
        
    }
}
